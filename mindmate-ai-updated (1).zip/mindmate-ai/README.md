# MindMate AI — Phase 1 + 2 + 3: Foundation + AI Chat + Mood Tracker

**Your Personal AI Wellness Companion**

This build now includes **Phase 1** (auth + full-stack foundation), **Phase 2** (AI chat with
memory), and **Phase 3** (mood tracker), all fully working end-to-end and Dockerized. Later phases
add habit/journal modules, planner, insights, and AWS deployment configs, building on top of this
base.

## What's included

**Phase 1 — Foundation**
- **Backend (FastAPI + PostgreSQL + SQLAlchemy + Alembic)**
  - Signup / Login / Refresh / Logout endpoints
  - JWT access tokens + rotating opaque refresh tokens, bcrypt password hashing
  - "Remember me" (longer-lived refresh token) and forgot/reset password flow (dev-mode: reset
    token is printed to the backend logs instead of emailed — real email delivery comes with the
    notifications phase)
  - `User` and `Profile` models + an initial Alembic migration
  - `/api/users/me` (get profile) and `/api/users/me/profile` (update goals)
- **Frontend (React + Vite + Tailwind + Framer Motion + React Router)**
  - Landing page: hero, features, how-it-works, testimonials, pricing, footer
  - Signup, Login, Forgot Password pages wired to the real API
  - Protected `/dashboard` route with auto token refresh on 401
  - Dashboard: editable wellness goals (sleep, water, stress) + a roadmap preview of upcoming modules
  - Light/dark mode, glassmorphism cards, rounded/soft "Apple-inspired" styling
- **Docker Compose**: Postgres + backend + frontend, one command to run everything

**Phase 2 — AI Chat with Memory** (powered by Google Gemini's free tier)
- Real streaming chat (tokens arrive live, not all at once)
- Wellness-companion personality: warm, remembers your name/goals, encourages healthy routines,
  avoids toxic positivity, never diagnoses or prescribes, and redirects to real help in a crisis
- Long-term memory: after each exchange, a running summary of your goals/preferences/routines is
  updated and fed back into every future conversation — the AI actually remembers you over time
- Multiple conversations: create, rename, pin, search, and delete chats
- Markdown rendering (including code blocks) in AI replies
- Export a conversation to a `.md` file
- Auto-generated chat titles from your first message
- New DB tables: `Chat`, `Message`, `AIMemory` (migration `0002`)

**Phase 3 — Mood Tracker**
- Daily check-in: mood, stress, energy, sleep quality (1-10 sliders) + optional note
- One entry per day per user (re-submitting the same day updates it instead of duplicating)
- Weekly / Monthly / All-time line graphs (mood, stress, energy, sleep quality together)
- AI-generated, non-diagnostic insight summarizing recent patterns (via Gemini)
- New DB table: `MoodLog` (migration `0003`)

## Not yet built (upcoming phases)

Habit tracker, journal, planner, statistics/charts, notifications/email, AWS deployment files,
and the remaining database tables (Habits, HabitLogs, Tasks, Goals, Settings, Notifications).
These will be added in the same "fully working, no placeholders" way, layer by layer.

## Project structure

```
mindmate-ai/
├── backend/
│   ├── app/
│   │   ├── main.py          # FastAPI app + CORS + routers
│   │   ├── config.py        # env-driven settings
│   │   ├── database.py      # SQLAlchemy engine/session
│   │   ├── models.py        # User, Profile, RefreshToken
│   │   ├── schemas.py       # Pydantic request/response models
│   │   ├── auth.py          # hashing, JWT, get_current_user dependency
│   │   └── routers/
│   │       ├── auth.py      # signup/login/refresh/logout/forgot/reset
│   │       └── users.py     # /me, /me/profile
│   ├── alembic/             # migrations
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── pages/           # Landing, Login, Signup, ForgotPassword, Dashboard
│   │   ├── components/      # Navbar, ProtectedRoute
│   │   ├── context/         # AuthContext
│   │   └── api/axios.js     # axios instance + auto refresh interceptor
│   └── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

## Running it locally with Docker (recommended)

1. Copy the environment file and fill in a real JWT secret:
   ```bash
   cp .env.example .env
   ```
2. Start everything:
   ```bash
   docker compose up --build
   ```
3. Visit:
   - Frontend: http://localhost:5173
   - Backend API docs (Swagger): http://localhost:8000/docs
   - Health check: http://localhost:8000/api/health

The backend container automatically runs `alembic upgrade head` on startup, so the database
schema is created for you — no manual migration step needed.

## Running it without Docker

**Backend**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# Point DATABASE_URL at a local Postgres instance, e.g.:
# postgresql+psycopg2://mindmate:mindmate@localhost:5432/mindmate
alembic upgrade head
uvicorn app.main:app --reload
```

**Frontend**
```bash
cd frontend
npm install
npm run dev
```

## Environment variables

See `.env.example`. You now need:
- `DATABASE_URL`
- `JWT_SECRET_KEY` (generate with `openssl rand -hex 32`)
- `CORS_ORIGINS` (must include your frontend URL)
- `GEMINI_API_KEY` — get a free key (no credit card) at https://aistudio.google.com → "Get API key"
  → "Create API key". Without this, chat requests will fail with a Gemini auth error.

`OPENAI_API_KEY` is present as an optional alternate provider but isn't used by default.

## API quick reference (this phase)

| Method | Endpoint                     | Auth required | Description                       |
|--------|-------------------------------|:--------------:|------------------------------------|
| POST   | `/api/auth/signup`            | No             | Create account, returns tokens     |
| POST   | `/api/auth/login`             | No             | Log in, returns tokens             |
| POST   | `/api/auth/refresh`           | No             | Exchange refresh token for new pair|
| POST   | `/api/auth/logout`            | No             | Revoke a refresh token             |
| POST   | `/api/auth/forgot-password`   | No             | Request password reset             |
| POST   | `/api/auth/reset-password`    | No             | Reset password with token          |
| GET    | `/api/users/me`               | Yes            | Get current user + profile         |
| PUT    | `/api/users/me/profile`       | Yes            | Update wellness goals/profile      |
| GET    | `/api/chats`                  | Yes            | List chats (optional `?search=`)   |
| POST   | `/api/chats`                  | Yes            | Create a new chat                  |
| PUT    | `/api/chats/{id}`              | Yes            | Rename or pin/unpin a chat          |
| DELETE | `/api/chats/{id}`              | Yes            | Delete a chat                      |
| GET    | `/api/chats/{id}/messages`     | Yes            | Get all messages in a chat         |
| POST   | `/api/chats/{id}/messages`     | Yes            | Send a message; streams AI reply   |
| POST   | `/api/mood/checkin`            | Yes            | Create/update today's mood check-in|
| GET    | `/api/mood/today`               | Yes            | Get today's check-in (or null)     |
| GET    | `/api/mood`                     | Yes            | List mood logs (`?range=week/month/all`) |
| GET    | `/api/mood/insights`             | Yes            | AI-generated insight from recent logs |

## A note on scope

The original spec covers a very large product surface (AI companion, mood/habit/journal/planner,
insights, statistics, notifications, AWS deployment, etc.). Rather than generating a shallow
sketch of all of it at once, this phase is fully functional end-to-end — real auth, real database,
real UI wired to the real API. Tell me which module you'd like next (AI chat is the natural next
step) and it'll be built the same way: complete and working, not stubbed out.
