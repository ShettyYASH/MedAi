import typography from "@tailwindcss/typography";

/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "#f2f6ff",
          100: "#e4ecff",
          200: "#c9d9ff",
          300: "#a3bdff",
          400: "#7d9dff",
          500: "#5b7cf5",
          600: "#4560db",
          700: "#3549ad",
          800: "#2c3c87",
          900: "#26336d",
        },
        calm: {
          50: "#f6f8f6",
          100: "#eaf1ea",
          200: "#d3e3d4",
        },
      },
      fontFamily: {
        sans: [
          "Inter",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "sans-serif",
        ],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      backdropBlur: {
        xs: "2px",
      },
    },
  },
  plugins: [typography],
};
