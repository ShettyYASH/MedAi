import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [dark, setDark] = useState(() => localStorage.getItem("theme") === "dark");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  return (
    <nav className="sticky top-0 z-50 glass-card mx-4 mt-4 flex items-center justify-between px-6 py-3 md:mx-8">
      <Link to="/" className="text-lg font-semibold text-primary-700 dark:text-primary-200">
        🧠 MindMate AI
      </Link>

      <div className="flex items-center gap-3">
        <button
          onClick={() => setDark((d) => !d)}
          className="rounded-full p-2 text-lg hover:bg-white/60 dark:hover:bg-white/10"
          aria-label="Toggle dark mode"
        >
          {dark ? "☀️" : "🌙"}
        </button>

        {user ? (
          <>
            <Link to="/chat" className="btn-secondary !px-4 !py-2 text-sm">
              Chat
            </Link>
            <Link to="/mood" className="btn-secondary !px-4 !py-2 text-sm">
              Mood
            </Link>
            <Link to="/habits" className="btn-secondary !px-4 !py-2 text-sm">
              Habits
            </Link>
            <Link to="/journal" className="btn-secondary !px-4 !py-2 text-sm">
              Journal
            </Link>
            <Link to="/planner" className="btn-secondary !px-4 !py-2 text-sm">
              Planner
            </Link>
            <Link to="/insights" className="btn-secondary !px-4 !py-2 text-sm">
              Insights
            </Link>
            <Link to="/dashboard" className="btn-secondary !px-4 !py-2 text-sm">
              Dashboard
            </Link>
            <button
              onClick={async () => {
                await logout();
                navigate("/");
              }}
              className="btn-primary !px-4 !py-2 text-sm"
            >
              Log out
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn-secondary !px-4 !py-2 text-sm">
              Log in
            </Link>
            <Link to="/signup" className="btn-primary !px-4 !py-2 text-sm">
              Get started
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}
