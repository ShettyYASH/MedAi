import React, { useState } from "react";

export default function ChatSidebar({
  chats,
  activeChatId,
  onSelectChat,
  onNewChat,
  onSearch,
  onRename,
  onDelete,
  onTogglePin,
}) {
  const [renamingId, setRenamingId] = useState(null);
  const [renameValue, setRenameValue] = useState("");
  const [search, setSearch] = useState("");

  const submitSearch = (value) => {
    setSearch(value);
    onSearch(value);
  };

  const startRename = (chat) => {
    setRenamingId(chat.id);
    setRenameValue(chat.title);
  };

  const confirmRename = (chatId) => {
    if (renameValue.trim()) onRename(chatId, renameValue.trim());
    setRenamingId(null);
  };

  return (
    <div className="flex h-full w-72 flex-col border-r border-gray-200 dark:border-white/10">
      <div className="p-4">
        <button onClick={onNewChat} className="btn-primary w-full !py-2.5 text-sm">
          + New chat
        </button>
        <input
          type="text"
          placeholder="Search conversations…"
          className="input-field mt-3 !py-2 text-sm"
          value={search}
          onChange={(e) => submitSearch(e.target.value)}
        />
      </div>

      <div className="flex-1 overflow-y-auto px-2 pb-4">
        {chats.length === 0 && (
          <p className="px-3 py-6 text-center text-sm text-gray-400">No conversations yet.</p>
        )}
        {chats.map((chat) => (
          <div
            key={chat.id}
            className={`group mb-1 flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm transition ${
              chat.id === activeChatId
                ? "bg-primary-100 dark:bg-primary-900/40"
                : "hover:bg-white/60 dark:hover:bg-white/5"
            }`}
          >
            {renamingId === chat.id ? (
              <input
                autoFocus
                className="input-field !py-1 flex-1 text-xs"
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                onBlur={() => confirmRename(chat.id)}
                onKeyDown={(e) => e.key === "Enter" && confirmRename(chat.id)}
              />
            ) : (
              <button
                onClick={() => onSelectChat(chat.id)}
                className="flex-1 truncate text-left"
                title={chat.title}
              >
                {chat.pinned && <span className="mr-1">📌</span>}
                {chat.title}
              </button>
            )}

            <div className="hidden gap-1 group-hover:flex">
              <button
                onClick={() => onTogglePin(chat)}
                title={chat.pinned ? "Unpin" : "Pin"}
                className="rounded p-1 text-xs hover:bg-black/5 dark:hover:bg-white/10"
              >
                📌
              </button>
              <button
                onClick={() => startRename(chat)}
                title="Rename"
                className="rounded p-1 text-xs hover:bg-black/5 dark:hover:bg-white/10"
              >
                ✏️
              </button>
              <button
                onClick={() => onDelete(chat.id)}
                title="Delete"
                className="rounded p-1 text-xs hover:bg-black/5 dark:hover:bg-white/10"
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
