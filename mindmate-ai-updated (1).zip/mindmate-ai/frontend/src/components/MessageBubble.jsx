import React from "react";
import ReactMarkdown from "react-markdown";

export default function MessageBubble({ role, content, streaming }) {
  const isUser = role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
          isUser
            ? "bg-primary-600 text-white"
            : "glass-card text-gray-800 dark:text-gray-100"
        }`}
      >
        {isUser ? (
          <p className="whitespace-pre-wrap">{content}</p>
        ) : (
          <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-1.5 prose-pre:bg-gray-900 prose-pre:text-gray-100">
            <ReactMarkdown>{content || " "}</ReactMarkdown>
            {streaming && (
              <span className="ml-0.5 inline-block h-3.5 w-1.5 animate-pulse bg-primary-500 align-middle" />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
