import React, { useEffect, useRef } from "react";

const TOOLS = [
  { cmd: "bold", label: "B", title: "Bold", className: "font-bold" },
  { cmd: "italic", label: "I", title: "Italic", className: "italic" },
  { cmd: "underline", label: "U", title: "Underline", className: "underline" },
  { cmd: "insertUnorderedList", label: "•—", title: "Bullet list", className: "" },
  { cmd: "insertOrderedList", label: "1.", title: "Numbered list", className: "" },
];

/**
 * A minimal rich-text editor built on contentEditable + document.execCommand.
 * No external dependency - keeps the project's package.json untouched.
 * `value` is HTML; `onChange(html)` fires on every edit.
 */
export default function RichTextEditor({ value, onChange, placeholder = "Write here…" }) {
  const editorRef = useRef(null);
  const isFirstRender = useRef(true);

  // Only push external `value` into the DOM when it actually changes from
  // outside (e.g. loading a different day's entry) - never on every
  // keystroke, or the cursor would jump to the start on each render.
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== (value || "")) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  const exec = (cmd) => {
    document.execCommand(cmd, false, undefined);
    editorRef.current?.focus();
    onChange(editorRef.current?.innerHTML || "");
  };

  const handleInput = () => {
    onChange(editorRef.current?.innerHTML || "");
  };

  return (
    <div className="glass-card overflow-hidden">
      <div className="flex flex-wrap gap-1 border-b border-white/40 p-2 dark:border-white/10">
        {TOOLS.map((t) => (
          <button
            key={t.cmd}
            type="button"
            title={t.title}
            onMouseDown={(e) => e.preventDefault()} // keep editor selection when clicking toolbar
            onClick={() => exec(t.cmd)}
            className={`min-w-[2rem] rounded-md px-2 py-1 text-sm hover:bg-white/70 dark:hover:bg-white/10 ${t.className}`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onInput={handleInput}
        data-placeholder={placeholder}
        className="rich-editor min-h-[220px] px-4 py-3 text-sm leading-relaxed outline-none"
      />
    </div>
  );
}
