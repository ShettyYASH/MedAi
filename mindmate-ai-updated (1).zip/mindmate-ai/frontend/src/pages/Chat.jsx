import React, { useEffect, useRef, useState } from "react";
import ChatSidebar from "../components/ChatSidebar.jsx";
import MessageBubble from "../components/MessageBubble.jsx";
import * as chatApi from "../api/chat.js";

export default function Chat() {
  const [chats, setChats] = useState([]);
  const [activeChatId, setActiveChatId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [streamingText, setStreamingText] = useState(null); // null = not streaming
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [error, setError] = useState("");
  const scrollRef = useRef(null);

  const refreshChats = async (search = "") => {
    const data = await chatApi.listChats(search);
    setChats(data);
    return data;
  };

  useEffect(() => {
    (async () => {
      const data = await refreshChats();
      if (data.length > 0) {
        selectChat(data[0].id);
      } else {
        handleNewChat();
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, streamingText]);

  const selectChat = async (chatId) => {
    setActiveChatId(chatId);
    setLoadingMessages(true);
    setStreamingText(null);
    try {
      const data = await chatApi.getMessages(chatId);
      setMessages(data);
    } finally {
      setLoadingMessages(false);
    }
  };

  const handleNewChat = async () => {
    const chat = await chatApi.createChat();
    setChats((prev) => [chat, ...prev]);
    setActiveChatId(chat.id);
    setMessages([]);
  };

  const handleSearch = async (value) => {
    await refreshChats(value);
  };

  const handleRename = async (chatId, title) => {
    await chatApi.updateChat(chatId, { title });
    await refreshChats();
  };

  const handleTogglePin = async (chat) => {
    await chatApi.updateChat(chat.id, { pinned: !chat.pinned });
    await refreshChats();
  };

  const handleDelete = async (chatId) => {
    if (!confirm("Delete this conversation? This can't be undone.")) return;
    await chatApi.deleteChat(chatId);
    const remaining = await refreshChats();
    if (chatId === activeChatId) {
      if (remaining.length > 0) selectChat(remaining[0].id);
      else handleNewChat();
    }
  };

  const handleExport = () => {
    const lines = messages.map((m) => `**${m.role === "user" ? "You" : "MindMate"}:** ${m.content}`);
    const blob = new Blob([lines.join("\n\n")], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mindmate-conversation.md";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSend = async (e) => {
    e.preventDefault();
    const content = input.trim();
    if (!content || streamingText !== null || !activeChatId) return;

    setError("");
    setInput("");
    setMessages((prev) => [...prev, { id: `temp-user-${Date.now()}`, role: "user", content }]);
    setStreamingText("");

    await chatApi.streamMessage(activeChatId, content, {
      onChunk: (chunk) => setStreamingText((prev) => (prev ?? "") + chunk),
      onDone: () => {
        setStreamingText((finalText) => {
          setMessages((prev) => [
            ...prev,
            { id: `temp-assistant-${Date.now()}`, role: "assistant", content: finalText || "" },
          ]);
          return null;
        });
        refreshChats(); // pick up auto-generated title / updated ordering
      },
      onError: (err) => {
        setError(err.message || "Something went wrong. Please try again.");
        setStreamingText(null);
      },
    });
  };

  return (
    <div className="flex h-[calc(100vh-88px)]">
      <ChatSidebar
        chats={chats}
        activeChatId={activeChatId}
        onSelectChat={selectChat}
        onNewChat={handleNewChat}
        onSearch={handleSearch}
        onRename={handleRename}
        onDelete={handleDelete}
        onTogglePin={handleTogglePin}
      />

      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between border-b border-gray-200 px-6 py-3 dark:border-white/10">
          <h2 className="font-medium text-gray-700 dark:text-gray-200">
            {chats.find((c) => c.id === activeChatId)?.title || "Conversation"}
          </h2>
          <button
            onClick={handleExport}
            disabled={messages.length === 0}
            className="btn-secondary !px-3 !py-1.5 text-xs disabled:opacity-40"
          >
            Export
          </button>
        </div>

        <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-6 py-6">
          {loadingMessages && <p className="text-center text-sm text-gray-400">Loading…</p>}

          {!loadingMessages && messages.length === 0 && streamingText === null && (
            <div className="flex h-full flex-col items-center justify-center text-center text-gray-400">
              <p className="text-lg">👋 Say hello to MindMate</p>
              <p className="mt-1 text-sm">Ask about your goals, talk through your day, or just check in.</p>
            </div>
          )}

          {messages.map((m) => (
            <MessageBubble key={m.id} role={m.role} content={m.content} />
          ))}

          {streamingText !== null && (
            <MessageBubble role="assistant" content={streamingText} streaming />
          )}
        </div>

        {error && (
          <div className="mx-6 mb-2 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700 dark:bg-red-900/30 dark:text-red-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSend} className="flex gap-3 border-t border-gray-200 p-4 dark:border-white/10">
          <input
            className="input-field flex-1"
            placeholder="Message MindMate…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={streamingText !== null}
          />
          <button type="submit" disabled={streamingText !== null || !input.trim()} className="btn-primary">
            {streamingText !== null ? "…" : "Send"}
          </button>
        </form>

        <p className="px-6 pb-3 text-center text-xs text-gray-400">
          MindMate AI is not a licensed therapist. In a crisis, please contact local emergency
          services or a crisis helpline.
        </p>
      </div>
    </div>
  );
}
