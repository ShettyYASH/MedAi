import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import api from "../api/axios";

export default function Dashboard() {
  const { user, refreshUser } = useAuth();
  const [form, setForm] = useState({
    name: user?.profile?.name || "",
    sleep_goal_hours: user?.profile?.sleep_goal_hours || "",
    water_goal_ml: user?.profile?.water_goal_ml || "",
    stress_level: user?.profile?.stress_level || "",
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const displayName = user?.profile?.name || user?.email?.split("@")[0] || "there";

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      const payload = {
        ...form,
        sleep_goal_hours: form.sleep_goal_hours ? Number(form.sleep_goal_hours) : null,
        water_goal_ml: form.water_goal_ml ? Number(form.water_goal_ml) : null,
        stress_level: form.stress_level ? Number(form.stress_level) : null,
      };
      await api.put("/api/users/me/profile", payload);
      await refreshUser();
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-10 md:px-8">
      <h1 className="text-3xl font-semibold">Welcome back, {displayName} 👋</h1>
      <p className="mt-1 text-gray-500 dark:text-gray-400">
        Here's your space. Update your goals below, or jump into any module.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* Profile / goals form */}
        <div className="glass-card p-6 lg:col-span-1">
          <h2 className="text-lg font-semibold">Your goals</h2>
          <form onSubmit={handleSave} className="mt-4 space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium">Display name</label>
              <input
                className="input-field"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Sleep goal (hrs/night)</label>
              <input
                type="number"
                min="0"
                max="24"
                className="input-field"
                value={form.sleep_goal_hours}
                onChange={(e) => setForm({ ...form, sleep_goal_hours: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Water goal (ml/day)</label>
              <input
                type="number"
                min="0"
                className="input-field"
                value={form.water_goal_ml}
                onChange={(e) => setForm({ ...form, water_goal_ml: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium">Current stress level (1–10)</label>
              <input
                type="number"
                min="1"
                max="10"
                className="input-field"
                value={form.stress_level}
                onChange={(e) => setForm({ ...form, stress_level: e.target.value })}
              />
            </div>
            <button type="submit" disabled={saving} className="btn-primary w-full">
              {saving ? "Saving…" : "Save goals"}
            </button>
            {saved && <p className="text-center text-sm text-green-600 dark:text-green-400">Saved!</p>}
          </form>
        </div>

        {/* Roadmap of upcoming modules */}
        <div className="lg:col-span-2">
          <Link
            to="/chat"
            className="glass-card mb-4 flex items-center justify-between p-5 transition hover:bg-white/80 dark:hover:bg-white/10"
          >
            <div>
              <h2 className="text-lg font-semibold">💬 Chat with MindMate</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Your AI companion remembers your goals and past conversations — say hello.
              </p>
            </div>
            <span className="btn-primary !px-4 !py-2 text-sm">Open chat →</span>
          </Link>

          <Link
            to="/mood"
            className="glass-card mb-6 flex items-center justify-between p-5 transition hover:bg-white/80 dark:hover:bg-white/10"
          >
            <div>
              <h2 className="text-lg font-semibold">📈 Mood Tracker</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Log today's mood, stress, energy, and sleep in a few seconds.
              </p>
            </div>
            <span className="btn-primary !px-4 !py-2 text-sm">Check in →</span>
          </Link>

          <Link
            to="/habits"
            className="glass-card mb-6 flex items-center justify-between p-5 transition hover:bg-white/80 dark:hover:bg-white/10"
          >
            <div>
              <h2 className="text-lg font-semibold">✅ Habit Tracker</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Water, sleep, exercise, and custom habits — build your streaks.
              </p>
            </div>
            <span className="btn-primary !px-4 !py-2 text-sm">View habits →</span>
          </Link>

          <Link
            to="/journal"
            className="glass-card mb-6 flex items-center justify-between p-5 transition hover:bg-white/80 dark:hover:bg-white/10"
          >
            <div>
              <h2 className="text-lg font-semibold">📓 Journal</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                Write a rich-text daily entry and get a short AI reflection.
              </p>
            </div>
            <span className="btn-primary !px-4 !py-2 text-sm">Open journal →</span>
          </Link>

          <Link
            to="/planner"
            className="glass-card mb-6 flex items-center justify-between p-5 transition hover:bg-white/80 dark:hover:bg-white/10"
          >
            <div>
              <h2 className="text-lg font-semibold">🗓️ Daily Planner</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                To-dos, a 7-day calendar view, and a Pomodoro focus timer.
              </p>
            </div>
            <span className="btn-primary !px-4 !py-2 text-sm">Open planner →</span>
          </Link>

          <Link
            to="/insights"
            className="glass-card mb-6 flex items-center justify-between p-5 transition hover:bg-white/80 dark:hover:bg-white/10"
          >
            <div>
              <h2 className="text-lg font-semibold">📊 Insights</h2>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                A weekly or monthly AI wellness report pulled from everything above.
              </p>
            </div>
            <span className="btn-primary !px-4 !py-2 text-sm">View report →</span>
          </Link>
        </div>
      </div>

      <p className="mt-10 rounded-xl bg-amber-50 px-4 py-3 text-xs text-amber-800 dark:bg-amber-900/20 dark:text-amber-200">
        MindMate AI is a wellness companion, not a licensed therapist or medical provider. If you're in
        crisis or thinking about harming yourself, please contact local emergency services or a crisis
        helpline right away.
      </p>
    </div>
  );
}
