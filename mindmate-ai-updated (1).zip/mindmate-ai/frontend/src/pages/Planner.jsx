import React, { useEffect, useMemo, useRef, useState } from "react";
import * as plannerApi from "../api/planner.js";

const PRIORITY_STYLES = {
  low: "bg-gray-100 text-gray-600 dark:bg-white/10 dark:text-gray-300",
  medium: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  high: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
};

function toISODate(d) {
  return d.toISOString().slice(0, 10);
}

function next7Days() {
  const days = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    days.push(d);
  }
  return days;
}

function formatDayLabel(d, todayISO) {
  const iso = toISODate(d);
  if (iso === todayISO) return "Today";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

// ---------------- Pomodoro timer ----------------

const WORK_SECONDS = 25 * 60;
const BREAK_SECONDS = 5 * 60;

function PomodoroTimer() {
  const [mode, setMode] = useState("work"); // "work" | "break"
  const [secondsLeft, setSecondsLeft] = useState(WORK_SECONDS);
  const [running, setRunning] = useState(false);
  const [taskLabel, setTaskLabel] = useState("");
  const [stats, setStats] = useState({ sessions_today: 0, focus_minutes_today: 0 });
  const intervalRef = useRef(null);

  const loadStats = async () => {
    try {
      const data = await plannerApi.getPomodoroTodayStats();
      setStats(data);
    } catch {
      // best-effort - don't block the timer UI on this
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSecondsLeft((s) => s - 1);
      }, 1000);
    }
    return () => clearInterval(intervalRef.current);
  }, [running]);

  useEffect(() => {
    if (secondsLeft > 0) return;
    clearInterval(intervalRef.current);
    setRunning(false);

    if (mode === "work") {
      plannerApi.logPomodoroSession({ task_label: taskLabel || null, duration_minutes: 25 }).then(loadStats);
      setMode("break");
      setSecondsLeft(BREAK_SECONDS);
    } else {
      setMode("work");
      setSecondsLeft(WORK_SECONDS);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft]);

  const reset = () => {
    setRunning(false);
    setMode("work");
    setSecondsLeft(WORK_SECONDS);
  };

  const minutes = String(Math.floor(Math.max(secondsLeft, 0) / 60)).padStart(2, "0");
  const seconds = String(Math.max(secondsLeft, 0) % 60).padStart(2, "0");
  const totalForMode = mode === "work" ? WORK_SECONDS : BREAK_SECONDS;
  const progress = 1 - Math.max(secondsLeft, 0) / totalForMode;

  return (
    <div className="glass-card p-6 text-center">
      <h2 className="text-lg font-semibold">🍅 Pomodoro Timer</h2>
      <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
        {mode === "work" ? "Focus time" : "Break time"}
      </p>

      <div className="relative mx-auto my-6 flex h-40 w-40 items-center justify-center">
        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full -rotate-90">
          <circle cx="50" cy="50" r="45" fill="none" strokeWidth="8" className="stroke-white/40 dark:stroke-white/10" />
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={2 * Math.PI * 45}
            strokeDashoffset={2 * Math.PI * 45 * (1 - progress)}
            className={mode === "work" ? "stroke-primary-600" : "stroke-green-500"}
          />
        </svg>
        <span className="text-3xl font-semibold tabular-nums">
          {minutes}:{seconds}
        </span>
      </div>

      <input
        className="input-field mb-4 text-center text-sm"
        placeholder="What are you focusing on?"
        value={taskLabel}
        onChange={(e) => setTaskLabel(e.target.value)}
        disabled={running}
      />

      <div className="flex justify-center gap-3">
        <button onClick={() => setRunning((r) => !r)} className="btn-primary !px-6 !py-2 text-sm">
          {running ? "Pause" : "Start"}
        </button>
        <button onClick={reset} className="btn-secondary !px-6 !py-2 text-sm">
          Reset
        </button>
      </div>

      <p className="mt-5 text-xs text-gray-500 dark:text-gray-400">
        {stats.sessions_today} session{stats.sessions_today === 1 ? "" : "s"} today ·{" "}
        {stats.focus_minutes_today} focus min
      </p>
    </div>
  );
}

// ---------------- Planner page ----------------

export default function Planner() {
  const todayISO = toISODate(new Date());
  const days = useMemo(() => next7Days(), []);

  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    due_date: todayISO,
    due_time: "",
    priority: "medium",
  });

  const loadTodos = async () => {
    setLoading(true);
    try {
      const data = await plannerApi.listTodos({ include_completed: true });
      setTodos(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTodos();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    setCreating(true);
    try {
      await plannerApi.createTodo({
        title: form.title.trim(),
        description: form.description || null,
        due_date: form.due_date || null,
        due_time: form.due_time || null,
        priority: form.priority,
      });
      setForm({ title: "", description: "", due_date: todayISO, due_time: "", priority: "medium" });
      setShowForm(false);
      await loadTodos();
    } finally {
      setCreating(false);
    }
  };

  const handleToggle = async (todo) => {
    await plannerApi.updateTodo(todo.id, { is_completed: !todo.is_completed });
    await loadTodos();
  };

  const handleDelete = async (todo) => {
    await plannerApi.deleteTodo(todo.id);
    await loadTodos();
  };

  const todosByDate = useMemo(() => {
    const map = {};
    todos.forEach((t) => {
      if (!t.due_date) return;
      (map[t.due_date] ||= []).push(t);
    });
    return map;
  }, [todos]);

  const unscheduled = todos.filter((t) => !t.due_date && !t.is_completed);

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-10 md:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Daily Planner</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            To-dos, a 7-day calendar view, and a Pomodoro timer to help you focus.
          </p>
        </div>
        <button onClick={() => setShowForm((s) => !s)} className="btn-primary !px-4 !py-2 text-sm">
          {showForm ? "Cancel" : "+ Add to-do"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="glass-card mt-6 grid gap-4 p-6 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="mb-1 block text-sm font-medium">Title</label>
            <input
              className="input-field"
              placeholder="e.g. Finish project outline"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1 block text-sm font-medium">Notes (optional)</label>
            <textarea
              className="input-field"
              rows={2}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Due date</label>
            <input
              type="date"
              className="input-field"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Due time (optional)</label>
            <input
              type="time"
              className="input-field"
              value={form.due_time}
              onChange={(e) => setForm({ ...form, due_time: e.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1 block text-sm font-medium">Priority</label>
            <div className="flex gap-2">
              {["low", "medium", "high"].map((p) => (
                <button
                  type="button"
                  key={p}
                  onClick={() => setForm({ ...form, priority: p })}
                  className={`rounded-full px-4 py-1.5 text-sm capitalize transition ${
                    form.priority === p
                      ? "bg-primary-600 text-white"
                      : "bg-white/60 text-gray-600 hover:bg-white dark:bg-white/10 dark:text-gray-300"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
          <div className="sm:col-span-2">
            <button type="submit" disabled={creating} className="btn-primary w-full sm:w-auto">
              {creating ? "Adding…" : "Add to-do"}
            </button>
          </div>
        </form>
      )}

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* Calendar / to-do list */}
        <div className="lg:col-span-2">
          {loading ? (
            <p className="py-16 text-center text-sm text-gray-400">Loading…</p>
          ) : (
            <div className="space-y-5">
              {days.map((d) => {
                const iso = toISODate(d);
                const items = (todosByDate[iso] || []).slice().sort((a, b) =>
                  (a.due_time || "99:99").localeCompare(b.due_time || "99:99")
                );
                return (
                  <div key={iso} className="glass-card p-5">
                    <h3 className="text-sm font-semibold text-primary-700 dark:text-primary-300">
                      {formatDayLabel(d, todayISO)}
                    </h3>
                    {items.length === 0 ? (
                      <p className="mt-2 text-xs text-gray-400">Nothing scheduled.</p>
                    ) : (
                      <ul className="mt-3 space-y-2">
                        {items.map((t) => (
                          <li
                            key={t.id}
                            className="flex items-start justify-between gap-3 rounded-lg bg-white/50 px-3 py-2 dark:bg-white/5"
                          >
                            <div className="flex items-start gap-3">
                              <input
                                type="checkbox"
                                checked={t.is_completed}
                                onChange={() => handleToggle(t)}
                                className="mt-1 h-4 w-4 accent-primary-600"
                              />
                              <div>
                                <p className={`text-sm ${t.is_completed ? "text-gray-400 line-through" : ""}`}>
                                  {t.title}
                                </p>
                                <div className="mt-1 flex items-center gap-2 text-[11px]">
                                  {t.due_time && <span className="text-gray-400">{t.due_time}</span>}
                                  <span className={`rounded-full px-2 py-0.5 ${PRIORITY_STYLES[t.priority]}`}>
                                    {t.priority}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <button
                              onClick={() => handleDelete(t)}
                              className="text-gray-400 hover:text-red-500"
                              aria-label={`Delete ${t.title}`}
                            >
                              🗑️
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}

              {unscheduled.length > 0 && (
                <div className="glass-card p-5">
                  <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400">Someday / no date</h3>
                  <ul className="mt-3 space-y-2">
                    {unscheduled.map((t) => (
                      <li
                        key={t.id}
                        className="flex items-start justify-between gap-3 rounded-lg bg-white/50 px-3 py-2 dark:bg-white/5"
                      >
                        <div className="flex items-start gap-3">
                          <input
                            type="checkbox"
                            checked={t.is_completed}
                            onChange={() => handleToggle(t)}
                            className="mt-1 h-4 w-4 accent-primary-600"
                          />
                          <p className="text-sm">{t.title}</p>
                        </div>
                        <button
                          onClick={() => handleDelete(t)}
                          className="text-gray-400 hover:text-red-500"
                          aria-label={`Delete ${t.title}`}
                        >
                          🗑️
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Pomodoro timer */}
        <div>
          <PomodoroTimer />
        </div>
      </div>
    </div>
  );
}
