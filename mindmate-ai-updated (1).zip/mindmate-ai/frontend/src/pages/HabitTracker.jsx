import React, { useEffect, useState } from "react";
import * as habitsApi from "../api/habits.js";

const CATEGORY_PRESETS = {
  water: { emoji: "💧", unit: "glasses", target_value: 8, label: "Water" },
  sleep: { emoji: "😴", unit: "hours", target_value: 8, label: "Sleep" },
  exercise: { emoji: "🏋️", unit: "minutes", target_value: 30, label: "Exercise" },
  custom: { emoji: "✅", unit: "", target_value: null, label: "Custom" },
};

function last7Days() {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d);
  }
  return days;
}

function toISODate(d) {
  return d.toISOString().slice(0, 10);
}

export default function HabitTracker() {
  const [habits, setHabits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    name: "",
    category: "custom",
    emoji: "✅",
    target_value: "",
    unit: "",
  });

  // habitId -> { [isoDate]: log }
  const [logsByHabit, setLogsByHabit] = useState({});

  const week = last7Days();

  const loadHabits = async () => {
    setLoading(true);
    try {
      const data = await habitsApi.listHabits();
      setHabits(data);
      const logEntries = await Promise.all(
        data.map(async (h) => {
          const logs = await habitsApi.listHabitLogs(h.id, "week");
          const map = {};
          logs.forEach((l) => {
            map[l.log_date] = l;
          });
          return [h.id, map];
        })
      );
      setLogsByHabit(Object.fromEntries(logEntries));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHabits();
  }, []);

  const handleCategoryChange = (category) => {
    const preset = CATEGORY_PRESETS[category];
    setForm((f) => ({
      ...f,
      category,
      emoji: preset.emoji,
      unit: preset.unit,
      target_value: preset.target_value ?? "",
      name: f.name || preset.label,
    }));
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    setCreating(true);
    try {
      await habitsApi.createHabit({
        name: form.name.trim(),
        category: form.category,
        emoji: form.emoji || "✅",
        target_value: form.target_value ? Number(form.target_value) : null,
        unit: form.unit || null,
      });
      setForm({ name: "", category: "custom", emoji: "✅", target_value: "", unit: "" });
      setShowForm(false);
      await loadHabits();
    } finally {
      setCreating(false);
    }
  };

  const handleToggleToday = async (habit) => {
    const todayISO = toISODate(new Date());
    const todayLog = logsByHabit[habit.id]?.[todayISO];
    const nextCompleted = !(todayLog?.completed ?? habit.completed_today);
    await habitsApi.checkInHabit(habit.id, { completed: nextCompleted });
    await loadHabits();
  };

  const handleDelete = async (habit) => {
    if (!window.confirm(`Delete "${habit.name}"? This removes all of its history.`)) return;
    await habitsApi.deleteHabit(habit.id);
    await loadHabits();
  };

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-10 md:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Habit Tracker</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Small daily wins add up — check in each day and watch your streaks grow.
          </p>
        </div>
        <button onClick={() => setShowForm((s) => !s)} className="btn-primary !px-4 !py-2 text-sm">
          {showForm ? "Cancel" : "+ Add habit"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="glass-card mt-6 grid gap-4 p-6 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="mb-1 block text-sm font-medium">Category</label>
            <div className="flex flex-wrap gap-2">
              {Object.entries(CATEGORY_PRESETS).map(([key, preset]) => (
                <button
                  type="button"
                  key={key}
                  onClick={() => handleCategoryChange(key)}
                  className={`rounded-full px-4 py-1.5 text-sm transition ${
                    form.category === key
                      ? "bg-primary-600 text-white"
                      : "bg-white/60 text-gray-600 hover:bg-white dark:bg-white/10 dark:text-gray-300"
                  }`}
                >
                  {preset.emoji} {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">Habit name</label>
            <input
              className="input-field"
              placeholder="e.g. Drink water"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">Emoji</label>
            <input
              className="input-field"
              maxLength={4}
              value={form.emoji}
              onChange={(e) => setForm({ ...form, emoji: e.target.value })}
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">Daily target (optional)</label>
            <input
              type="number"
              min="1"
              className="input-field"
              placeholder="e.g. 8"
              value={form.target_value}
              onChange={(e) => setForm({ ...form, target_value: e.target.value })}
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">Unit (optional)</label>
            <input
              className="input-field"
              placeholder="e.g. glasses, minutes"
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
            />
          </div>

          <div className="sm:col-span-2">
            <button type="submit" disabled={creating} className="btn-primary w-full sm:w-auto">
              {creating ? "Adding…" : "Add habit"}
            </button>
          </div>
        </form>
      )}

      <div className="mt-8 space-y-4">
        {loading ? (
          <p className="py-16 text-center text-sm text-gray-400">Loading…</p>
        ) : habits.length === 0 ? (
          <div className="glass-card p-10 text-center text-sm text-gray-400">
            No habits yet — add water, sleep, exercise, or a custom habit to start building streaks.
          </div>
        ) : (
          habits.map((habit) => {
            const habitLogs = logsByHabit[habit.id] || {};
            return (
              <div key={habit.id} className="glass-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{habit.emoji}</span>
                    <div>
                      <h3 className="font-semibold">{habit.name}</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {habit.target_value
                          ? `Goal: ${habit.target_value} ${habit.unit || ""} / day`
                          : "Daily habit"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-primary-600 dark:text-primary-300">
                        🔥 {habit.current_streak}
                      </div>
                      <div className="text-[11px] text-gray-400">current streak</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-semibold">{habit.longest_streak}</div>
                      <div className="text-[11px] text-gray-400">best streak</div>
                    </div>

                    <button
                      onClick={() => handleToggleToday(habit)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                        habit.completed_today
                          ? "bg-green-600 text-white hover:bg-green-700"
                          : "btn-secondary"
                      }`}
                    >
                      {habit.completed_today ? "✓ Done today" : "Mark done"}
                    </button>

                    <button
                      onClick={() => handleDelete(habit)}
                      className="text-gray-400 hover:text-red-500"
                      aria-label={`Delete ${habit.name}`}
                      title="Delete habit"
                    >
                      🗑️
                    </button>
                  </div>
                </div>

                {/* 7-day grid */}
                <div className="mt-4 flex gap-2">
                  {week.map((d) => {
                    const iso = toISODate(d);
                    const log = habitLogs[iso];
                    const isToday = iso === toISODate(new Date());
                    const done = !!log?.completed;
                    return (
                      <div key={iso} className="flex flex-1 flex-col items-center gap-1">
                        <span className="text-[10px] text-gray-400">
                          {d.toLocaleDateString(undefined, { weekday: "narrow" })}
                        </span>
                        <div
                          className={`h-7 w-full rounded-md ${
                            done
                              ? "bg-primary-600"
                              : "bg-white/60 dark:bg-white/10"
                          } ${isToday ? "ring-2 ring-primary-400" : ""}`}
                          title={iso}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
