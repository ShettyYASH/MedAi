import React, { useEffect, useState } from "react";
import * as journalApi from "../api/journal.js";
import RichTextEditor from "../components/RichTextEditor.jsx";

const MOOD_TAGS = ["😊", "😐", "😔", "😡", "😴", "🤩", "😰"];

function toISODate(d) {
  return d.toISOString().slice(0, 10);
}

function formatDate(iso) {
  return new Date(iso + "T00:00:00").toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

export default function Journal() {
  const todayISO = toISODate(new Date());

  const [selectedDate, setSelectedDate] = useState(todayISO);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [moodTag, setMoodTag] = useState(null);
  const [currentEntryId, setCurrentEntryId] = useState(null);

  const [entries, setEntries] = useState([]);
  const [loadingList, setLoadingList] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);
  const [summarizing, setSummarizing] = useState(false);
  const [summary, setSummary] = useState(null);

  const loadEntries = async () => {
    setLoadingList(true);
    try {
      const data = await journalApi.listEntries("month");
      setEntries(data);
      return data;
    } finally {
      setLoadingList(false);
    }
  };

  const loadIntoEditor = (list, dateISO) => {
    const found = list.find((e) => e.entry_date === dateISO);
    if (found) {
      setCurrentEntryId(found.id);
      setTitle(found.title || "");
      setContent(found.content || "");
      setMoodTag(found.mood_tag || null);
      setSummary(found.ai_summary || null);
    } else {
      setCurrentEntryId(null);
      setTitle("");
      setContent("");
      setMoodTag(null);
      setSummary(null);
    }
  };

  useEffect(() => {
    loadEntries().then((data) => loadIntoEditor(data, todayISO));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSelectDate = (dateISO) => {
    setSelectedDate(dateISO);
    loadIntoEditor(entries, dateISO);
  };

  const handleSave = async () => {
    setSaving(true);
    setSavedAt(null);
    try {
      const saved = await journalApi.saveEntry({
        entry_date: selectedDate,
        title: title || null,
        content: content || "<p></p>",
        mood_tag: moodTag,
      });
      setCurrentEntryId(saved.id);
      setSavedAt(new Date());
      await loadEntries();
    } finally {
      setSaving(false);
    }
  };

  const handleSummarize = async () => {
    if (!currentEntryId) {
      await handleSave();
    }
    setSummarizing(true);
    try {
      // re-fetch id in case this is a first save
      const list = await journalApi.listEntries("month");
      setEntries(list);
      const entry = list.find((e) => e.entry_date === selectedDate);
      if (!entry) return;
      const { summary: text } = await journalApi.summarizeEntry(entry.id);
      setSummary(text);
    } finally {
      setSummarizing(false);
    }
  };

  const handleDelete = async () => {
    if (!currentEntryId) return;
    if (!window.confirm("Delete this journal entry? This can't be undone.")) return;
    await journalApi.deleteEntry(currentEntryId);
    const list = await loadEntries();
    loadIntoEditor(list, selectedDate);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-10 md:px-8">
      <div>
        <h1 className="text-3xl font-semibold">Journal</h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          A private space to write daily — MindMate can reflect it back with a short AI summary.
        </p>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* Editor */}
        <div className="lg:col-span-2">
          <div className="glass-card mb-4 flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="flex items-center gap-2">
              <input
                type="date"
                className="input-field !w-auto"
                max={todayISO}
                value={selectedDate}
                onChange={(e) => handleSelectDate(e.target.value)}
              />
              <span className="text-sm text-gray-500 dark:text-gray-400">{formatDate(selectedDate)}</span>
            </div>
            <div className="flex items-center gap-1">
              {MOOD_TAGS.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setMoodTag(moodTag === tag ? null : tag)}
                  className={`rounded-full p-1.5 text-lg transition ${
                    moodTag === tag ? "bg-primary-600/20 ring-2 ring-primary-400" : "hover:bg-white/60 dark:hover:bg-white/10"
                  }`}
                  title="Tag today's mood"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          <input
            className="input-field mb-4 text-lg font-medium"
            placeholder="Title (optional)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <RichTextEditor value={content} onChange={setContent} placeholder="What's on your mind today?" />

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button onClick={handleSave} disabled={saving} className="btn-primary !px-5 !py-2.5 text-sm">
              {saving ? "Saving…" : "Save entry"}
            </button>
            <button
              onClick={handleSummarize}
              disabled={summarizing}
              className="btn-secondary !px-5 !py-2.5 text-sm"
            >
              {summarizing ? "Summarizing…" : "✨ AI summary"}
            </button>
            {currentEntryId && (
              <button onClick={handleDelete} className="text-sm text-gray-400 hover:text-red-500">
                Delete entry
              </button>
            )}
            {savedAt && <span className="text-sm text-green-600 dark:text-green-400">Saved ✓</span>}
          </div>

          {summary && (
            <div className="glass-card mt-5 p-5">
              <h3 className="text-sm font-semibold text-primary-700 dark:text-primary-300">✨ AI reflection</h3>
              <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{summary}</p>
            </div>
          )}
        </div>

        {/* Past entries */}
        <div>
          <h2 className="text-lg font-semibold">Past entries</h2>
          <div className="mt-4 space-y-3">
            {loadingList ? (
              <p className="py-8 text-center text-sm text-gray-400">Loading…</p>
            ) : entries.length === 0 ? (
              <div className="glass-card p-6 text-center text-sm text-gray-400">
                No entries yet — write your first one today.
              </div>
            ) : (
              entries.map((e) => (
                <button
                  key={e.id}
                  onClick={() => handleSelectDate(e.entry_date)}
                  className={`glass-card block w-full p-4 text-left transition hover:bg-white/80 dark:hover:bg-white/10 ${
                    e.entry_date === selectedDate ? "ring-2 ring-primary-400" : ""
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                      {formatDate(e.entry_date)}
                    </span>
                    {e.mood_tag && <span>{e.mood_tag}</span>}
                  </div>
                  {e.title && <p className="mt-1 truncate text-sm font-semibold">{e.title}</p>}
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
