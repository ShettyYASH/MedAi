import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const features = [
  { icon: "💬", title: "AI Companion Chat", desc: "A warm, memory-aware AI that gets to know your routines and goals over time." },
  { icon: "📈", title: "Mood & Habit Tracking", desc: "Log your mood, stress, sleep, and habits, and watch trends unfold over weeks and months." },
  { icon: "📓", title: "Guided Journaling", desc: "A calm space to reflect daily, with AI-assisted summaries of your entries." },
  { icon: "🗓️", title: "Daily Planner", desc: "To-dos, reminders, and a Pomodoro timer to keep your day gently on track." },
  { icon: "🌬️", title: "Wellness Toolkit", desc: "Breathing exercises, affirmations, and stress-relief techniques whenever you need them." },
  { icon: "📊", title: "Insights & Reports", desc: "Weekly and monthly summaries that highlight patterns and gentle suggestions." },
];

const steps = [
  { step: "1", title: "Create your account", desc: "Sign up in seconds and tell MindMate a little about yourself." },
  { step: "2", title: "Talk & track daily", desc: "Chat with your companion, log your mood, and build habits that stick." },
  { step: "3", title: "Grow with insights", desc: "Get personalized, judgment-free insights as your history builds up." },
];

const testimonials = [
  { name: "Priya S.", quote: "It feels like checking in with a friend who actually remembers what I told them last week." },
  { name: "Daniel K.", quote: "The habit streaks kept me consistent with my sleep schedule for the first time in years." },
  { name: "Amara O.", quote: "Journaling used to feel like a chore. Now it's the calmest ten minutes of my day." },
];

const plans = [
  { name: "Free", price: "$0", features: ["AI chat (limited)", "Mood tracker", "Basic habit tracker"] },
  { name: "Plus", price: "$9/mo", features: ["Unlimited AI chat", "Full habit & journal suite", "Weekly AI insights"] },
  { name: "Pro", price: "$19/mo", features: ["Everything in Plus", "Monthly wellness reports", "Priority support"] },
];

export default function Landing() {
  return (
    <div className="px-4 pb-24 md:px-8">
      {/* Hero */}
      <section className="relative mx-auto flex max-w-5xl flex-col items-center overflow-hidden py-24 text-center">
        <motion.div
          className="absolute -top-32 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-primary-200/50 blur-3xl dark:bg-primary-900/30"
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10 text-4xl font-bold tracking-tight md:text-6xl"
        >
          Your Personal <span className="text-primary-600 dark:text-primary-300">AI Wellness</span> Companion
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="relative z-10 mt-6 max-w-2xl text-lg text-gray-600 dark:text-gray-300"
        >
          MindMate AI remembers you, tracks your habits and mood, and helps you build a calmer,
          healthier daily rhythm — one conversation at a time.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="relative z-10 mt-8 flex gap-4"
        >
          <Link to="/signup" className="btn-primary">Start your journey — it's free</Link>
          <Link to="/login" className="btn-secondary">I already have an account</Link>
        </motion.div>
        <p className="relative z-10 mt-4 text-xs text-gray-500 dark:text-gray-400">
          MindMate AI is not a licensed therapist or medical provider. In a crisis, please contact
          local emergency services or a crisis helpline.
        </p>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl py-12">
        <h2 className="text-center text-3xl font-semibold">Everything you need to feel your best</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="glass-card p-6">
              <div className="text-3xl">{f.icon}</div>
              <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-5xl py-12">
        <h2 className="text-center text-3xl font-semibold">How it works</h2>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {steps.map((s) => (
            <div key={s.step} className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary-600 text-lg font-bold text-white">
                {s.step}
              </div>
              <h3 className="mt-4 text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="mx-auto max-w-6xl py-12">
        <h2 className="text-center text-3xl font-semibold">What people are saying</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="glass-card p-6">
              <p className="text-sm italic text-gray-700 dark:text-gray-200">"{t.quote}"</p>
              <p className="mt-4 text-sm font-semibold text-primary-700 dark:text-primary-300">— {t.name}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="mx-auto max-w-5xl py-12">
        <h2 className="text-center text-3xl font-semibold">Simple, honest pricing</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {plans.map((p) => (
            <div key={p.name} className="glass-card flex flex-col p-6">
              <h3 className="text-lg font-semibold">{p.name}</h3>
              <p className="mt-2 text-3xl font-bold">{p.price}</p>
              <ul className="mt-4 flex-1 space-y-2 text-sm text-gray-600 dark:text-gray-300">
                {p.features.map((f) => (
                  <li key={f}>✓ {f}</li>
                ))}
              </ul>
              <Link to="/signup" className="btn-primary mt-6 w-full">Choose {p.name}</Link>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto mt-16 max-w-6xl border-t border-gray-200 pt-8 text-center text-sm text-gray-500 dark:border-white/10 dark:text-gray-400">
        © {new Date().getFullYear()} MindMate AI. Not a substitute for professional medical or mental health care.
      </footer>
    </div>
  );
}
