import React, { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import * as moodApi from "../api/mood.js";

const SLIDER_FIELDS = [
  { key: "mood_score", label: "Mood", emoji: "🙂", required: true },
  { key: "stress_score", label: "Stress", emoji: "😰" },
  { key: "energy_score", label: "Energy", emoji: "⚡" },
  { key: "sleep_quality", label: "Sleep quality", emoji: "😴" },
];

export default function MoodTracker() {
  const [form, setForm] = useState({
    mood_score: 5,
    stress_score: 5,
    energy_score: 5,
    sleep_quality: 5,
    note: "",
  });
  const [todayLogged, setTodayLogged] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [range, setRange] = useState("month");
  const [logs, setLogs] = useState([]);
  const [loadingLogs, setLoadingLogs] = useState(true);

  const [insight, setInsight] = useState(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  const loadToday = async () => {
    const today = await moodApi.getToday();
    if (today) {
      setForm({
        mood_score: today.mood_score,
        stress_score: today.stress_score ?? 5,
        energy_score: today.energy_score ?? 5,
        sleep_quality: today.sleep_quality ?? 5,
        note: today.note ?? "",
      });
      setTodayLogged(true);
    }
  };

  const loadLogs = async (r) => {
    setLoadingLogs(true);
    try {
      const data = await moodApi.listMoodLogs(r);
      setLogs(
        data.map((d) => ({
          ...d,
          dateLabel: new Date(d.log_date).toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
          }),
        }))
      );
    } finally {
      setLoadingLogs(false);
    }
  };

  useEffect(() => {
    loadToday();
  }, []);

  useEffect(() => {
    loadLogs(range);
  }, [range]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      await moodApi.checkIn(form);
      setTodayLogged(true);
      setSaved(true);
      await loadLogs(range);
    } finally {
      setSaving(false);
    }
  };

  const handleGetInsight = async () => {
    setLoadingInsight(true);
    setInsight(null);
    try {
      const data = await moodApi.getInsights(range === "week" ? "week" : "month");
      setInsight(data);
    } finally {
      setLoadingInsight(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-10 md:px-8">
      <h1 className="text-3xl font-semibold">Mood Tracker</h1>
      <p className="mt-1 text-gray-500 dark:text-gray-400">
        A quick daily check-in helps you (and MindMate) notice patterns over time.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* Check-in form */}
        <div className="glass-card p-6 lg:col-span-1">
          <h2 className="text-lg font-semibold">
            {todayLogged ? "Update today's check-in" : "Today's check-in"}
          </h2>
          <form onSubmit={handleSave} className="mt-4 space-y-5">
            {SLIDER_FIELDS.map((f) => (
              <div key={f.key}>
                <div className="mb-1 flex items-center justify-between text-sm font-medium">
                  <span>
                    {f.emoji} {f.label}
                  </span>
                  <span className="text-primary-600 dark:text-primary-300">{form[f.key]}/10</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={form[f.key]}
                  onChange={(e) => setForm({ ...form, [f.key]: Number(e.target.value) })}
                  className="w-full accent-primary-600"
                />
              </div>
            ))}

            <div>
              <label className="mb-1 block text-sm font-medium">Quick note (optional)</label>
              <textarea
                rows={3}
                className="input-field resize-none"
                placeholder="Anything on your mind today?"
                value={form.note}
                onChange={(e) => setForm({ ...form, note: e.target.value })}
              />
            </div>

            <button type="submit" disabled={saving} className="btn-primary w-full">
              {saving ? "Saving…" : todayLogged ? "Update check-in" : "Save check-in"}
            </button>
            {saved && <p className="text-center text-sm text-green-600 dark:text-green-400">Saved!</p>}
          </form>
        </div>

        {/* Graphs + insights */}
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Trends</h2>
            <div className="flex gap-2">
              {["week", "month", "all"].map((r) => (
                <button
                  key={r}
                  onClick={() => setRange(r)}
                  className={`rounded-full px-4 py-1.5 text-sm capitalize transition ${
                    range === r
                      ? "bg-primary-600 text-white"
                      : "bg-white/60 text-gray-600 hover:bg-white dark:bg-white/10 dark:text-gray-300"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div className="glass-card mt-4 p-6">
            {loadingLogs ? (
              <p className="py-16 text-center text-sm text-gray-400">Loading…</p>
            ) : logs.length === 0 ? (
              <p className="py-16 text-center text-sm text-gray-400">
                No check-ins yet in this range — log today's mood to get started.
              </p>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={logs}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="dateLabel" tick={{ fontSize: 12 }} />
                  <YAxis domain={[0, 10]} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="mood_score" name="Mood" stroke="#5b7cf5" strokeWidth={2} />
                  <Line type="monotone" dataKey="stress_score" name="Stress" stroke="#f59e0b" strokeWidth={2} />
                  <Line type="monotone" dataKey="energy_score" name="Energy" stroke="#10b981" strokeWidth={2} />
                  <Line
                    type="monotone"
                    dataKey="sleep_quality"
                    name="Sleep quality"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="glass-card mt-6 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">✨ AI Insight</h3>
              <button
                onClick={handleGetInsight}
                disabled={loadingInsight}
                className="btn-secondary !px-3 !py-1.5 text-xs"
              >
                {loadingInsight ? "Thinking…" : "Generate insight"}
              </button>
            </div>
            {insight && (
              <p className="mt-3 text-sm leading-relaxed text-gray-700 dark:text-gray-200">
                {insight.insight}
              </p>
            )}
            {!insight && !loadingInsight && (
              <p className="mt-3 text-sm text-gray-400">
                Click "Generate insight" for a quick, judgment-free read on your recent patterns.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
