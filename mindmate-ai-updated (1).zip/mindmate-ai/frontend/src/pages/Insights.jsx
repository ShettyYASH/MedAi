import React, { useEffect, useState } from "react";
import * as insightsApi from "../api/insights.js";

function StatCard({ label, value, sub }) {
  return (
    <div className="glass-card p-4 text-center">
      <div className="text-2xl font-semibold text-primary-700 dark:text-primary-300">{value}</div>
      <div className="mt-1 text-xs font-medium text-gray-500 dark:text-gray-400">{label}</div>
      {sub && <div className="mt-0.5 text-[11px] text-gray-400">{sub}</div>}
    </div>
  );
}

export default function Insights() {
  const [range, setRange] = useState("week");
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = async (r) => {
    setLoading(true);
    setError(false);
    try {
      const data = await insightsApi.getWellnessReport(r);
      setReport(data);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(range);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range]);

  const rangeLabel = range === "week" ? "this week" : "this month";

  return (
    <div className="mx-auto max-w-5xl px-4 pb-24 pt-10 md:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Insights</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            An AI-generated wellness report pulled from your mood, habits, journal, and planner activity.
          </p>
        </div>
        <div className="flex gap-2">
          {["week", "month"].map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`rounded-full px-4 py-1.5 text-sm capitalize transition ${
                range === r
                  ? "bg-primary-600 text-white"
                  : "bg-white/60 text-gray-600 hover:bg-white dark:bg-white/10 dark:text-gray-300"
              }`}
            >
              {r}ly
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <p className="py-20 text-center text-sm text-gray-400">Building your report…</p>
      ) : error ? (
        <div className="glass-card mt-8 p-6 text-center text-sm text-gray-400">
          Couldn't load your report right now — please try again in a moment.
        </div>
      ) : (
        <>
          {/* AI narrative */}
          <div className="glass-card mt-8 p-6">
            <h2 className="text-sm font-semibold text-primary-700 dark:text-primary-300">
              ✨ Your {rangeLabel} report
            </h2>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-gray-700 dark:text-gray-200">
              {report.ai_report}
            </p>
          </div>

          {/* Mood */}
          <h2 className="mt-8 text-lg font-semibold">Mood</h2>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <StatCard label="Check-ins" value={report.mood.entry_count} />
            <StatCard label="Avg mood" value={report.mood.avg_mood ?? "—"} sub={report.mood.avg_mood ? "/ 10" : null} />
            <StatCard label="Avg stress" value={report.mood.avg_stress ?? "—"} sub={report.mood.avg_stress ? "/ 10" : null} />
            <StatCard label="Avg sleep" value={report.mood.avg_sleep_quality ?? "—"} sub={report.mood.avg_sleep_quality ? "/ 10" : null} />
          </div>

          {/* Habits */}
          <h2 className="mt-8 text-lg font-semibold">Habits</h2>
          {report.habits.length === 0 ? (
            <div className="glass-card mt-3 p-6 text-center text-sm text-gray-400">
              No habits tracked yet.
            </div>
          ) : (
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {report.habits.map((h) => (
                <div key={h.name} className="glass-card p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">
                      {h.emoji} {h.name}
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {h.completions}/{h.days_in_range} days
                    </span>
                  </div>
                  <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-white/60 dark:bg-white/10">
                    <div
                      className="h-full rounded-full bg-primary-600"
                      style={{ width: `${Math.round(h.completion_rate * 100)}%` }}
                    />
                  </div>
                  <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                    🔥 {h.current_streak} current · {h.longest_streak} best streak
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Journal + Planner */}
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <div className="glass-card p-5">
              <h2 className="text-lg font-semibold">📓 Journal</h2>
              <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                {report.journal.entry_count} entries {rangeLabel}
              </p>
              {report.journal.top_mood_tags.length > 0 && (
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                  Most common tags: {report.journal.top_mood_tags.join(" ")}
                </p>
              )}
            </div>
            <div className="glass-card p-5">
              <h2 className="text-lg font-semibold">🗓️ Planner</h2>
              <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                {report.planner.todos_completed}/{report.planner.todos_total} to-dos completed
              </p>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                {report.planner.pomodoro_sessions} focus sessions · {report.planner.pomodoro_minutes} min
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
