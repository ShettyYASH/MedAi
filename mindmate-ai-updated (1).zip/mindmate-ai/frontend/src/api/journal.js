import api from "./axios";

export async function saveEntry(payload) {
  const { data } = await api.post("/api/journal", payload);
  return data;
}

export async function getTodayEntry() {
  const { data } = await api.get("/api/journal/today");
  return data;
}

export async function listEntries(range = "month") {
  const { data } = await api.get("/api/journal", { params: { range } });
  return data;
}

export async function deleteEntry(entryId) {
  const { data } = await api.delete(`/api/journal/${entryId}`);
  return data;
}

export async function summarizeEntry(entryId) {
  const { data } = await api.post(`/api/journal/${entryId}/summarize`);
  return data;
}
