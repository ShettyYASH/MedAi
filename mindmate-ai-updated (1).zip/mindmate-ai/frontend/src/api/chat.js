import api from "./axios";

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export async function listChats(search = "") {
  const { data } = await api.get("/api/chats", { params: search ? { search } : {} });
  return data;
}

export async function createChat(title) {
  const { data } = await api.post("/api/chats", { title });
  return data;
}

export async function updateChat(chatId, payload) {
  const { data } = await api.put(`/api/chats/${chatId}`, payload);
  return data;
}

export async function deleteChat(chatId) {
  await api.delete(`/api/chats/${chatId}`);
}

export async function getMessages(chatId) {
  const { data } = await api.get(`/api/chats/${chatId}/messages`);
  return data;
}

/**
 * Streams the AI's reply for a new message.
 * Calls onChunk(text) as each piece arrives, and onDone() when finished.
 * Handles 401 by attempting a token refresh (mirrors axios interceptor logic)
 * since fetch() streaming isn't covered by the axios interceptor.
 */
export async function streamMessage(chatId, content, { onChunk, onDone, onError }) {
  const token = localStorage.getItem("access_token");

  const doRequest = async (accessToken) =>
    fetch(`${API_BASE_URL}/api/chats/${chatId}/messages`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({ content }),
    });

  try {
    let response = await doRequest(token);

    if (response.status === 401) {
      const refreshToken = localStorage.getItem("refresh_token");
      if (!refreshToken) throw new Error("Session expired. Please log in again.");

      const refreshResp = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });
      if (!refreshResp.ok) throw new Error("Session expired. Please log in again.");

      const refreshed = await refreshResp.json();
      localStorage.setItem("access_token", refreshed.access_token);
      localStorage.setItem("refresh_token", refreshed.refresh_token);
      response = await doRequest(refreshed.access_token);
    }

    if (!response.ok || !response.body) {
      throw new Error(`Request failed with status ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const text = decoder.decode(value, { stream: true });
      if (text) onChunk(text);
    }
    onDone();
  } catch (err) {
    onError(err);
  }
}
