import api from "./axios";

// ---------- To-dos ----------

export async function createTodo(payload) {
  const { data } = await api.post("/api/planner/todos", payload);
  return data;
}

export async function listTodos(params = {}) {
  const { data } = await api.get("/api/planner/todos", { params });
  return data;
}

export async function updateTodo(todoId, payload) {
  const { data } = await api.patch(`/api/planner/todos/${todoId}`, payload);
  return data;
}

export async function deleteTodo(todoId) {
  const { data } = await api.delete(`/api/planner/todos/${todoId}`);
  return data;
}

// ---------- Pomodoro ----------

export async function logPomodoroSession(payload = {}) {
  const { data } = await api.post("/api/planner/pomodoro", payload);
  return data;
}

export async function getPomodoroTodayStats() {
  const { data } = await api.get("/api/planner/pomodoro/today");
  return data;
}
