import api from "./axios";

export async function getWellnessReport(range = "week") {
  const { data } = await api.get("/api/insights/report", { params: { range } });
  return data;
}
