import api from "./axios";

export async function checkIn(payload) {
  const { data } = await api.post("/api/mood/checkin", payload);
  return data;
}

export async function getToday() {
  const { data } = await api.get("/api/mood/today");
  return data; // may be null
}

export async function listMoodLogs(range = "month") {
  const { data } = await api.get("/api/mood", { params: { range } });
  return data;
}

export async function getInsights(range = "month") {
  const { data } = await api.get("/api/mood/insights", { params: { range } });
  return data;
}
