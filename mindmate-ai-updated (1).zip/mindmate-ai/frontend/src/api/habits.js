import api from "./axios";

export async function listHabits() {
  const { data } = await api.get("/api/habits");
  return data;
}

export async function createHabit(payload) {
  const { data } = await api.post("/api/habits", payload);
  return data;
}

export async function updateHabit(habitId, payload) {
  const { data } = await api.patch(`/api/habits/${habitId}`, payload);
  return data;
}

export async function deleteHabit(habitId) {
  const { data } = await api.delete(`/api/habits/${habitId}`);
  return data;
}

export async function checkInHabit(habitId, payload = {}) {
  const { data } = await api.post(`/api/habits/${habitId}/checkin`, payload);
  return data;
}

export async function listHabitLogs(habitId, range = "month") {
  const { data } = await api.get(`/api/habits/${habitId}/logs`, { params: { range } });
  return data;
}
