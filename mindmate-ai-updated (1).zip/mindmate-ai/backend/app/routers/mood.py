from datetime import date, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app import models, schemas, auth, ai
from app.database import get_db

router = APIRouter(prefix="/api/mood", tags=["mood"])


@router.post("/checkin", response_model=schemas.MoodLogOut)
def check_in(
    payload: schemas.MoodCheckIn,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Creates today's (or a specified date's) mood check-in, or updates it
    if one already exists for that day - one entry per user per day."""
    log_date = payload.log_date or date.today()

    existing = (
        db.query(models.MoodLog)
        .filter(models.MoodLog.user_id == current_user.id, models.MoodLog.log_date == log_date)
        .first()
    )

    if existing:
        existing.mood_score = payload.mood_score
        existing.stress_score = payload.stress_score
        existing.energy_score = payload.energy_score
        existing.sleep_quality = payload.sleep_quality
        existing.note = payload.note
        db.commit()
        db.refresh(existing)
        return existing

    entry = models.MoodLog(
        user_id=current_user.id,
        log_date=log_date,
        mood_score=payload.mood_score,
        stress_score=payload.stress_score,
        energy_score=payload.energy_score,
        sleep_quality=payload.sleep_quality,
        note=payload.note,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.get("/today", response_model=Optional[schemas.MoodLogOut])
def get_today(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(models.MoodLog)
        .filter(models.MoodLog.user_id == current_user.id, models.MoodLog.log_date == date.today())
        .first()
    )


@router.get("", response_model=list[schemas.MoodLogOut])
def list_mood_logs(
    range: str = Query("month", pattern="^(week|month|all)$"),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(models.MoodLog).filter(models.MoodLog.user_id == current_user.id)

    if range == "week":
        query = query.filter(models.MoodLog.log_date >= date.today() - timedelta(days=7))
    elif range == "month":
        query = query.filter(models.MoodLog.log_date >= date.today() - timedelta(days=30))
    # "all" applies no date filter

    return query.order_by(models.MoodLog.log_date.asc()).all()


@router.get("/insights", response_model=schemas.MoodInsight)
def get_insights(
    range: str = Query("month", pattern="^(week|month)$"),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    days = 7 if range == "week" else 30
    logs = (
        db.query(models.MoodLog)
        .filter(
            models.MoodLog.user_id == current_user.id,
            models.MoodLog.log_date >= date.today() - timedelta(days=days),
        )
        .order_by(models.MoodLog.log_date.asc())
        .all()
    )

    if len(logs) < 2:
        return schemas.MoodInsight(
            insight="Log a few more days of check-ins and I'll start spotting patterns for you.",
            entry_count=len(logs),
        )

    lines = []
    for log in logs:
        parts = [f"{log.log_date}: mood={log.mood_score}/10"]
        if log.stress_score:
            parts.append(f"stress={log.stress_score}/10")
        if log.energy_score:
            parts.append(f"energy={log.energy_score}/10")
        if log.sleep_quality:
            parts.append(f"sleep_quality={log.sleep_quality}/10")
        if log.note:
            parts.append(f'note="{log.note}"')
        lines.append(", ".join(parts))

    summary_text = "\n".join(lines)
    insight_text = ai.generate_mood_insight(summary_text)

    return schemas.MoodInsight(insight=insight_text, entry_count=len(logs))
