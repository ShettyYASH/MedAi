from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session, joinedload

from app import models, schemas, auth, ai
from app.database import get_db, SessionLocal

router = APIRouter(prefix="/api/chats", tags=["chat"])

MAX_HISTORY_MESSAGES = 20  # how many prior messages to feed back into Gemini for context


@router.get("", response_model=list[schemas.ChatOut])
def list_chats(
    search: Optional[str] = Query(None, description="Filter chats by title"),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(models.Chat).filter(models.Chat.user_id == current_user.id)
    if search:
        query = query.filter(models.Chat.title.ilike(f"%{search}%"))
    chats = query.order_by(models.Chat.pinned.desc(), models.Chat.updated_at.desc()).all()
    return chats


@router.post("", response_model=schemas.ChatOut, status_code=201)
def create_chat(
    payload: schemas.ChatCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    chat = models.Chat(user_id=current_user.id, title=payload.title or "New chat")
    db.add(chat)
    db.commit()
    db.refresh(chat)
    return chat


@router.put("/{chat_id}", response_model=schemas.ChatOut)
def update_chat(
    chat_id: str,
    payload: schemas.ChatUpdate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    chat = _get_owned_chat(db, chat_id, current_user.id)
    if payload.title is not None:
        chat.title = payload.title
    if payload.pinned is not None:
        chat.pinned = payload.pinned
    db.commit()
    db.refresh(chat)
    return chat


@router.delete("/{chat_id}", status_code=204)
def delete_chat(
    chat_id: str,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    chat = _get_owned_chat(db, chat_id, current_user.id)
    db.delete(chat)
    db.commit()
    return None


@router.get("/{chat_id}/messages", response_model=list[schemas.MessageOut])
def get_messages(
    chat_id: str,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    chat = _get_owned_chat(db, chat_id, current_user.id)
    return chat.messages


@router.post("/{chat_id}/messages")
def send_message(
    chat_id: str,
    payload: schemas.MessageCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    chat = _get_owned_chat(db, chat_id, current_user.id)

    # Persist the user's message immediately
    user_msg = models.Message(chat_id=chat.id, role="user", content=payload.content)
    db.add(user_msg)
    db.commit()

    # Auto-title new chats from the first message
    if chat.title == "New chat":
        chat.title = ai.generate_chat_title(payload.content)
        db.commit()

    # Load recent history (excluding the message we just added) for context
    history = (
        db.query(models.Message)
        .filter(models.Message.chat_id == chat.id, models.Message.id != user_msg.id)
        .order_by(models.Message.created_at.desc())
        .limit(MAX_HISTORY_MESSAGES)
        .all()
    )
    history.reverse()

    memory_row = db.query(models.AIMemory).filter(models.AIMemory.user_id == current_user.id).first()
    memory_summary = memory_row.summary if memory_row else ""

    # --- Everything below runs in a background thread, AFTER this request
    # handler returns and the `db` session above has already been closed by
    # FastAPI's dependency cleanup (a well-known StreamingResponse gotcha).
    # So: capture only plain Python values now (while the session is open),
    # and use a brand new, independent DB session for the post-stream writes.
    system_prompt = ai.build_system_prompt(current_user, memory_summary)
    history_data = [{"role": m.role, "content": m.content} for m in history]
    chat_id_value = chat.id
    user_id_value = current_user.id
    user_content = payload.content

    def event_stream():
        full_response = ""
        try:
            for chunk in ai.stream_chat_response(system_prompt, history_data, user_content):
                full_response += chunk
                yield chunk
        finally:
            if full_response:
                write_db = SessionLocal()
                try:
                    assistant_msg = models.Message(
                        chat_id=chat_id_value, role="assistant", content=full_response
                    )
                    write_db.add(assistant_msg)
                    write_db.flush()  # get assistant_msg.created_at

                    write_db.query(models.Chat).filter(models.Chat.id == chat_id_value).update(
                        {"updated_at": assistant_msg.created_at}
                    )

                    updated_summary = ai.update_memory_summary(memory_summary, user_content, full_response)
                    existing_memory = (
                        write_db.query(models.AIMemory)
                        .filter(models.AIMemory.user_id == user_id_value)
                        .first()
                    )
                    if existing_memory:
                        existing_memory.summary = updated_summary
                    else:
                        write_db.add(models.AIMemory(user_id=user_id_value, summary=updated_summary))

                    write_db.commit()
                except Exception:  # noqa: BLE001
                    import traceback

                    print("=== Failed to save assistant message / memory ===")
                    traceback.print_exc()
                    write_db.rollback()
                finally:
                    write_db.close()

    return StreamingResponse(event_stream(), media_type="text/plain")


def _get_owned_chat(db: Session, chat_id: str, user_id: str) -> models.Chat:
    chat = (
        db.query(models.Chat)
        .options(joinedload(models.Chat.messages))
        .filter(models.Chat.id == chat_id, models.Chat.user_id == user_id)
        .first()
    )
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    return chat
