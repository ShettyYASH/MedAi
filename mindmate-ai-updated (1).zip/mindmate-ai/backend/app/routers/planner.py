from datetime import date, datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db

router = APIRouter(prefix="/api/planner", tags=["planner"])


def _get_owned_todo(db: Session, todo_id: str, user_id: str) -> models.Todo:
    todo = (
        db.query(models.Todo)
        .filter(models.Todo.id == todo_id, models.Todo.user_id == user_id)
        .first()
    )
    if not todo:
        raise HTTPException(status_code=404, detail="To-do not found")
    return todo


# ---------- To-dos / calendar ----------

@router.post("/todos", response_model=schemas.TodoOut)
def create_todo(
    payload: schemas.TodoCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    todo = models.Todo(
        user_id=current_user.id,
        title=payload.title,
        description=payload.description,
        due_date=payload.due_date,
        due_time=payload.due_time,
        priority=payload.priority,
    )
    db.add(todo)
    db.commit()
    db.refresh(todo)
    return todo


@router.get("/todos", response_model=list[schemas.TodoOut])
def list_todos(
    start_date: Optional[date] = Query(None, description="Filter due_date >= start_date"),
    end_date: Optional[date] = Query(None, description="Filter due_date <= end_date"),
    include_completed: bool = Query(True),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Lists to-dos, optionally scoped to a date range for calendar views.
    Items with no due_date (unscheduled / "someday") are only returned when
    no date range filter is supplied."""
    query = db.query(models.Todo).filter(models.Todo.user_id == current_user.id)

    if not include_completed:
        query = query.filter(models.Todo.is_completed == False)  # noqa: E712

    if start_date or end_date:
        query = query.filter(models.Todo.due_date.isnot(None))
        if start_date:
            query = query.filter(models.Todo.due_date >= start_date)
        if end_date:
            query = query.filter(models.Todo.due_date <= end_date)

    todos = query.order_by(
        models.Todo.is_completed.asc(),
        models.Todo.due_date.asc().nulls_last(),
        models.Todo.due_time.asc().nulls_last(),
        models.Todo.created_at.asc(),
    ).all()
    return todos


@router.patch("/todos/{todo_id}", response_model=schemas.TodoOut)
def update_todo(
    todo_id: str,
    payload: schemas.TodoUpdate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    todo = _get_owned_todo(db, todo_id, current_user.id)

    updates = payload.model_dump(exclude_unset=True)
    was_completed = todo.is_completed
    for field, value in updates.items():
        setattr(todo, field, value)

    if "is_completed" in updates:
        if updates["is_completed"] and not was_completed:
            todo.completed_at = datetime.utcnow()
        elif not updates["is_completed"]:
            todo.completed_at = None

    db.commit()
    db.refresh(todo)
    return todo


@router.delete("/todos/{todo_id}")
def delete_todo(
    todo_id: str,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    todo = _get_owned_todo(db, todo_id, current_user.id)
    db.delete(todo)
    db.commit()
    return {"ok": True}


# ---------- Pomodoro ----------

@router.post("/pomodoro", response_model=schemas.PomodoroOut)
def log_pomodoro_session(
    payload: schemas.PomodoroCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Logs one completed Pomodoro focus session (called by the timer widget
    when a work interval finishes)."""
    session = models.PomodoroSession(
        user_id=current_user.id,
        task_label=payload.task_label,
        duration_minutes=payload.duration_minutes,
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


@router.get("/pomodoro/today", response_model=schemas.PomodoroStats)
def pomodoro_today_stats(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    start_of_day = datetime.combine(date.today(), datetime.min.time())
    sessions = (
        db.query(models.PomodoroSession)
        .filter(
            models.PomodoroSession.user_id == current_user.id,
            models.PomodoroSession.completed_at >= start_of_day,
        )
        .all()
    )
    return schemas.PomodoroStats(
        sessions_today=len(sessions),
        focus_minutes_today=sum(s.duration_minutes for s in sessions),
    )


@router.get("/pomodoro/recent", response_model=list[schemas.PomodoroOut])
def recent_pomodoro_sessions(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(models.PomodoroSession)
        .filter(
            models.PomodoroSession.user_id == current_user.id,
            models.PomodoroSession.completed_at >= datetime.utcnow() - timedelta(days=7),
        )
        .order_by(models.PomodoroSession.completed_at.desc())
        .all()
    )
