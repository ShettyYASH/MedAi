from datetime import date, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db

router = APIRouter(prefix="/api/habits", tags=["habits"])


def _get_owned_habit(db: Session, habit_id: str, user_id: str) -> models.Habit:
    habit = (
        db.query(models.Habit)
        .filter(models.Habit.id == habit_id, models.Habit.user_id == user_id)
        .first()
    )
    if not habit:
        raise HTTPException(status_code=404, detail="Habit not found")
    return habit


def _compute_streaks(logs: List[models.HabitLog]) -> tuple[int, int]:
    """Given a habit's logs (any order), returns (current_streak, longest_streak)
    counted in consecutive calendar days of `completed=True` entries.

    Current streak counts backward from today (or yesterday, so a habit isn't
    reset to 0 just because today hasn't been logged yet).
    """
    completed_dates = {log.log_date for log in logs if log.completed}
    if not completed_dates:
        return 0, 0

    # --- current streak ---
    current_streak = 0
    cursor = date.today()
    if cursor not in completed_dates:
        cursor -= timedelta(days=1)  # allow "not logged yet today" to not break the streak
    while cursor in completed_dates:
        current_streak += 1
        cursor -= timedelta(days=1)

    # --- longest streak ---
    longest_streak = 0
    run = 0
    prev_day: Optional[date] = None
    for d in sorted(completed_dates):
        if prev_day is not None and d == prev_day + timedelta(days=1):
            run += 1
        else:
            run = 1
        longest_streak = max(longest_streak, run)
        prev_day = d

    return current_streak, longest_streak


def _to_habit_out(habit: models.Habit) -> schemas.HabitOut:
    current_streak, longest_streak = _compute_streaks(habit.logs)
    today_log = next((log for log in habit.logs if log.log_date == date.today()), None)

    return schemas.HabitOut(
        id=habit.id,
        name=habit.name,
        category=habit.category,
        emoji=habit.emoji,
        target_value=habit.target_value,
        unit=habit.unit,
        is_archived=habit.is_archived,
        created_at=habit.created_at,
        updated_at=habit.updated_at,
        current_streak=current_streak,
        longest_streak=longest_streak,
        completed_today=bool(today_log and today_log.completed),
        today_value=today_log.value if today_log else None,
    )


@router.post("", response_model=schemas.HabitOut)
def create_habit(
    payload: schemas.HabitCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    habit = models.Habit(
        user_id=current_user.id,
        name=payload.name,
        category=payload.category,
        emoji=payload.emoji,
        target_value=payload.target_value,
        unit=payload.unit,
    )
    db.add(habit)
    db.commit()
    db.refresh(habit)
    return _to_habit_out(habit)


@router.get("", response_model=List[schemas.HabitOut])
def list_habits(
    include_archived: bool = Query(False),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(models.Habit).filter(models.Habit.user_id == current_user.id)
    if not include_archived:
        query = query.filter(models.Habit.is_archived == False)  # noqa: E712

    habits = query.order_by(models.Habit.created_at.asc()).all()
    return [_to_habit_out(h) for h in habits]


@router.patch("/{habit_id}", response_model=schemas.HabitOut)
def update_habit(
    habit_id: str,
    payload: schemas.HabitUpdate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    habit = _get_owned_habit(db, habit_id, current_user.id)

    updates = payload.model_dump(exclude_unset=True)
    for field, value in updates.items():
        setattr(habit, field, value)

    db.commit()
    db.refresh(habit)
    return _to_habit_out(habit)


@router.delete("/{habit_id}")
def delete_habit(
    habit_id: str,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    habit = _get_owned_habit(db, habit_id, current_user.id)
    db.delete(habit)
    db.commit()
    return {"ok": True}


@router.post("/{habit_id}/checkin", response_model=schemas.HabitOut)
def check_in(
    habit_id: str,
    payload: schemas.HabitCheckIn,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Marks a habit done (or not done / with a value) for a given day - one
    log entry per habit per day, re-submitting updates the existing entry."""
    habit = _get_owned_habit(db, habit_id, current_user.id)
    log_date = payload.log_date or date.today()

    existing = (
        db.query(models.HabitLog)
        .filter(models.HabitLog.habit_id == habit.id, models.HabitLog.log_date == log_date)
        .first()
    )

    if existing:
        existing.completed = payload.completed
        existing.value = payload.value
    else:
        db.add(
            models.HabitLog(
                habit_id=habit.id,
                user_id=current_user.id,
                log_date=log_date,
                completed=payload.completed,
                value=payload.value,
            )
        )

    db.commit()
    db.refresh(habit)
    return _to_habit_out(habit)


@router.get("/{habit_id}/logs", response_model=List[schemas.HabitLogOut])
def list_habit_logs(
    habit_id: str,
    range: str = Query("month", pattern="^(week|month|all)$"),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    habit = _get_owned_habit(db, habit_id, current_user.id)

    query = db.query(models.HabitLog).filter(models.HabitLog.habit_id == habit.id)
    if range == "week":
        query = query.filter(models.HabitLog.log_date >= date.today() - timedelta(days=7))
    elif range == "month":
        query = query.filter(models.HabitLog.log_date >= date.today() - timedelta(days=30))
    # "all" applies no date filter

    return query.order_by(models.HabitLog.log_date.asc()).all()
