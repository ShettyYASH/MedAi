from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db
from app.config import settings

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/signup", response_model=schemas.TokenResponse, status_code=status.HTTP_201_CREATED)
def signup(payload: schemas.SignupRequest, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="An account with this email already exists")

    user = models.User(
        email=payload.email,
        hashed_password=auth.hash_password(payload.password),
    )
    db.add(user)
    db.flush()  # get user.id before commit

    profile = models.Profile(user_id=user.id, name=payload.name)
    db.add(profile)
    db.commit()
    db.refresh(user)

    return _issue_tokens(user, db, remember_me=True)


@router.post("/login", response_model=schemas.TokenResponse)
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user or not auth.verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is deactivated")

    return _issue_tokens(user, db, remember_me=payload.remember_me)


@router.post("/refresh", response_model=schemas.TokenResponse)
def refresh(payload: schemas.RefreshRequest, db: Session = Depends(get_db)):
    token_row = (
        db.query(models.RefreshToken)
        .filter(models.RefreshToken.token == payload.refresh_token, models.RefreshToken.revoked == False)  # noqa: E712
        .first()
    )
    if not token_row or token_row.expires_at < datetime.utcnow():
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

    user = db.query(models.User).filter(models.User.id == token_row.user_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found or inactive")

    # Rotate refresh token
    token_row.revoked = True
    db.commit()

    return _issue_tokens(user, db, remember_me=True)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(payload: schemas.RefreshRequest, db: Session = Depends(get_db)):
    token_row = db.query(models.RefreshToken).filter(models.RefreshToken.token == payload.refresh_token).first()
    if token_row:
        token_row.revoked = True
        db.commit()
    return None


@router.post("/forgot-password", status_code=status.HTTP_202_ACCEPTED)
def forgot_password(payload: schemas.ForgotPasswordRequest, db: Session = Depends(get_db)):
    # For Step 1: always respond 202 to avoid leaking which emails exist.
    # Real email delivery (SES / SMTP) is wired up in a later phase.
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if user:
        reset_token = auth.create_access_token(user.id, expires_minutes=30)
        # TODO(step 4): send email via SES/SMTP containing a link with reset_token
        print(f"[DEV] Password reset token for {payload.email}: {reset_token}")
    return {"message": "If that email exists, a reset link has been sent."}


@router.post("/reset-password", status_code=status.HTTP_200_OK)
def reset_password(payload: schemas.ResetPasswordRequest, db: Session = Depends(get_db)):
    user_id = auth.decode_access_token(payload.token)
    if not user_id:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.hashed_password = auth.hash_password(payload.new_password)
    db.commit()
    return {"message": "Password updated successfully"}


def _issue_tokens(user: models.User, db: Session, remember_me: bool) -> schemas.TokenResponse:
    access_token = auth.create_access_token(user.id)
    refresh_value = auth.create_refresh_token_value()
    expire_days = settings.REFRESH_TOKEN_EXPIRE_DAYS if remember_me else 1

    refresh_row = models.RefreshToken(
        user_id=user.id,
        token=refresh_value,
        expires_at=datetime.utcnow() + timedelta(days=expire_days),
    )
    db.add(refresh_row)
    db.commit()

    return schemas.TokenResponse(access_token=access_token, refresh_token=refresh_value)
