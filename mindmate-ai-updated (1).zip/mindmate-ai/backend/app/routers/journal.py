import re
from datetime import date, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import models, schemas, auth, ai
from app.database import get_db

router = APIRouter(prefix="/api/journal", tags=["journal"])

_SCRIPT_TAG_RE = re.compile(r"<\s*script[^>]*>.*?<\s*/\s*script\s*>", re.IGNORECASE | re.DOTALL)
_STYLE_TAG_RE = re.compile(r"<\s*style[^>]*>.*?<\s*/\s*style\s*>", re.IGNORECASE | re.DOTALL)
_ON_ATTR_RE = re.compile(r'\s+on\w+\s*=\s*"[^"]*"', re.IGNORECASE)
_ON_ATTR_RE_SINGLE = re.compile(r"\s+on\w+\s*=\s*'[^']*'", re.IGNORECASE)
_JS_HREF_RE = re.compile(r'(href|src)\s*=\s*"javascript:[^"]*"', re.IGNORECASE)
_TAG_RE = re.compile(r"<[^>]+>")


def _sanitize_html(html: str) -> str:
    """Lightweight sanitizer for the journal's simple rich-text editor output.
    Strips <script>/<style> blocks, inline event handlers, and javascript: URLs.
    Not a full HTML sanitizer, but the editor only ever emits a small, known
    set of tags (b/i/u/ul/ol/li/br/div/p), so this covers the real risk."""
    cleaned = _SCRIPT_TAG_RE.sub("", html)
    cleaned = _STYLE_TAG_RE.sub("", cleaned)
    cleaned = _ON_ATTR_RE.sub("", cleaned)
    cleaned = _ON_ATTR_RE_SINGLE.sub("", cleaned)
    cleaned = _JS_HREF_RE.sub("", cleaned)
    return cleaned


def _plain_text(html: str) -> str:
    return _TAG_RE.sub(" ", html).strip()


def _get_owned_entry(db: Session, entry_id: str, user_id: str) -> models.JournalEntry:
    entry = (
        db.query(models.JournalEntry)
        .filter(models.JournalEntry.id == entry_id, models.JournalEntry.user_id == user_id)
        .first()
    )
    if not entry:
        raise HTTPException(status_code=404, detail="Journal entry not found")
    return entry


@router.post("", response_model=schemas.JournalEntryOut)
def save_entry(
    payload: schemas.JournalEntryCreate,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Creates or updates the journal entry for a given day (defaults to
    today) - one entry per user per calendar day, matching the mood/habit
    check-in pattern elsewhere in the app."""
    entry_date = payload.entry_date or date.today()
    clean_content = _sanitize_html(payload.content)

    existing = (
        db.query(models.JournalEntry)
        .filter(models.JournalEntry.user_id == current_user.id, models.JournalEntry.entry_date == entry_date)
        .first()
    )

    if existing:
        existing.title = payload.title
        existing.content = clean_content
        existing.mood_tag = payload.mood_tag
        existing.ai_summary = None  # content changed - stale summary invalidated
        db.commit()
        db.refresh(existing)
        return existing

    entry = models.JournalEntry(
        user_id=current_user.id,
        entry_date=entry_date,
        title=payload.title,
        content=clean_content,
        mood_tag=payload.mood_tag,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.get("/today", response_model=Optional[schemas.JournalEntryOut])
def get_today(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(models.JournalEntry)
        .filter(models.JournalEntry.user_id == current_user.id, models.JournalEntry.entry_date == date.today())
        .first()
    )


@router.get("", response_model=list[schemas.JournalEntryOut])
def list_entries(
    range: str = Query("month", pattern="^(week|month|all)$"),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(models.JournalEntry).filter(models.JournalEntry.user_id == current_user.id)

    if range == "week":
        query = query.filter(models.JournalEntry.entry_date >= date.today() - timedelta(days=7))
    elif range == "month":
        query = query.filter(models.JournalEntry.entry_date >= date.today() - timedelta(days=30))
    # "all" applies no date filter

    return query.order_by(models.JournalEntry.entry_date.desc()).all()


@router.delete("/{entry_id}")
def delete_entry(
    entry_id: str,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    entry = _get_owned_entry(db, entry_id, current_user.id)
    db.delete(entry)
    db.commit()
    return {"ok": True}


@router.post("/{entry_id}/summarize", response_model=schemas.JournalSummaryOut)
def summarize_entry(
    entry_id: str,
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Generates (and caches) an AI summary/reflection for one entry."""
    entry = _get_owned_entry(db, entry_id, current_user.id)

    text = _plain_text(entry.content)
    if len(text) < 10:
        raise HTTPException(status_code=400, detail="Write a bit more before summarizing.")

    summary = ai.generate_journal_summary(text)
    entry.ai_summary = summary
    db.commit()
    return schemas.JournalSummaryOut(summary=summary)
