from collections import Counter
from datetime import date, datetime, timedelta
from typing import List

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app import models, schemas, auth, ai
from app.database import get_db
from app.routers.habits import _compute_streaks

router = APIRouter(prefix="/api/insights", tags=["insights"])


def _avg(values: List[int]) -> float | None:
    values = [v for v in values if v is not None]
    return round(sum(values) / len(values), 1) if values else None


@router.get("/report", response_model=schemas.WellnessReport)
def get_wellness_report(
    range: str = Query("week", pattern="^(week|month)$"),
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    """Aggregates the user's mood, habit, journal, and planner activity over
    the last 7 or 30 days into a stat summary plus a short AI-written
    narrative report. Nothing here is persisted - it's computed fresh each
    time, the same way the mood insights endpoint works."""
    days = 7 if range == "week" else 30
    since = date.today() - timedelta(days=days)
    since_dt = datetime.combine(since, datetime.min.time())

    # ---- Mood ----
    mood_logs = (
        db.query(models.MoodLog)
        .filter(models.MoodLog.user_id == current_user.id, models.MoodLog.log_date >= since)
        .order_by(models.MoodLog.log_date.asc())
        .all()
    )
    mood_summary = schemas.MoodInsightsSummary(
        entry_count=len(mood_logs),
        avg_mood=_avg([m.mood_score for m in mood_logs]),
        avg_stress=_avg([m.stress_score for m in mood_logs]),
        avg_energy=_avg([m.energy_score for m in mood_logs]),
        avg_sleep_quality=_avg([m.sleep_quality for m in mood_logs]),
    )

    # ---- Habits ----
    habits = (
        db.query(models.Habit)
        .filter(models.Habit.user_id == current_user.id, models.Habit.is_archived == False)  # noqa: E712
        .all()
    )
    habit_summaries = []
    for h in habits:
        logs_in_range = [log for log in h.logs if log.log_date >= since]
        completions = sum(1 for log in logs_in_range if log.completed)
        current_streak, longest_streak = _compute_streaks(h.logs)
        habit_summaries.append(
            schemas.HabitInsightsSummary(
                name=h.name,
                emoji=h.emoji,
                completions=completions,
                days_in_range=days,
                completion_rate=round(completions / days, 2) if days else 0.0,
                current_streak=current_streak,
                longest_streak=longest_streak,
            )
        )

    # ---- Journal ----
    journal_entries = (
        db.query(models.JournalEntry)
        .filter(models.JournalEntry.user_id == current_user.id, models.JournalEntry.entry_date >= since)
        .all()
    )
    tag_counts = Counter(e.mood_tag for e in journal_entries if e.mood_tag)
    journal_summary = schemas.JournalInsightsSummary(
        entry_count=len(journal_entries),
        top_mood_tags=[tag for tag, _ in tag_counts.most_common(3)],
    )

    # ---- Planner ----
    todos_in_range = (
        db.query(models.Todo)
        .filter(models.Todo.user_id == current_user.id, models.Todo.created_at >= since_dt)
        .all()
    )
    pomodoro_sessions = (
        db.query(models.PomodoroSession)
        .filter(models.PomodoroSession.user_id == current_user.id, models.PomodoroSession.completed_at >= since_dt)
        .all()
    )
    planner_summary = schemas.PlannerInsightsSummary(
        todos_completed=sum(1 for t in todos_in_range if t.is_completed),
        todos_total=len(todos_in_range),
        pomodoro_sessions=len(pomodoro_sessions),
        pomodoro_minutes=sum(s.duration_minutes for s in pomodoro_sessions),
    )

    entry_count = mood_summary.entry_count + journal_summary.entry_count + len(habit_summaries) + len(todos_in_range)
    if entry_count == 0:
        ai_report = (
            f"Log a few mood check-ins, habits, or journal entries this {('week' if range == 'week' else 'month')} "
            "and I'll put together a real report for you."
        )
    else:
        lines = [
            f"Mood: {mood_summary.entry_count} check-ins, avg mood {mood_summary.avg_mood or 'n/a'}/10, "
            f"avg stress {mood_summary.avg_stress or 'n/a'}/10, avg energy {mood_summary.avg_energy or 'n/a'}/10, "
            f"avg sleep quality {mood_summary.avg_sleep_quality or 'n/a'}/10",
        ]
        for hs in habit_summaries:
            lines.append(
                f"Habit '{hs.name}': {hs.completions}/{hs.days_in_range} days completed "
                f"({round(hs.completion_rate * 100)}%), current streak {hs.current_streak}, "
                f"longest streak {hs.longest_streak}"
            )
        lines.append(
            f"Journal: {journal_summary.entry_count} entries"
            + (f", most common mood tags {', '.join(journal_summary.top_mood_tags)}" if journal_summary.top_mood_tags else "")
        )
        lines.append(
            f"Planner: {planner_summary.todos_completed}/{planner_summary.todos_total} to-dos completed, "
            f"{planner_summary.pomodoro_sessions} focus sessions totaling {planner_summary.pomodoro_minutes} minutes"
        )
        ai_report = ai.generate_wellness_report(range, "\n".join(lines))

    return schemas.WellnessReport(
        range=range,
        generated_at=datetime.utcnow(),
        mood=mood_summary,
        habits=habit_summaries,
        journal=journal_summary,
        planner=planner_summary,
        ai_report=ai_report,
    )
