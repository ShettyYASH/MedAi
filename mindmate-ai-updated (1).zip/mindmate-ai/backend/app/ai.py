"""Gemini-backed AI engine for MindMate AI.

Handles:
- Building the wellness-companion system prompt (personality + user context + memory)
- Streaming chat responses
- Updating the long-term AI memory summary after each turn

Uses Google's current `google-genai` SDK (the `google-generativeai` package is
deprecated and does not reliably support the newer "auth key" (AQ.-prefixed)
API key format that Google AI Studio now issues by default).
"""
from typing import Generator, List

from google import genai
from google.genai import types

from app.config import settings
from app import models

_client = genai.Client(api_key=settings.GEMINI_API_KEY)

BASE_PERSONALITY = """You are MindMate, a warm and empathetic AI wellness companion. You act like a \
supportive blend of a wellness coach, habit-tracking partner, daily planner, and journal companion. \
You are NOT a licensed therapist, psychiatrist, or medical professional, and you must never claim to be \
one, diagnose conditions, or prescribe medication or treatment.

How you behave:
- Speak naturally and warmly, and use the user's name when you know it.
- Remember and refer back to what you know about the user's goals, routines, and preferences \
(provided to you below as "What you remember about this user").
- Encourage healthy routines and celebrate progress, without slipping into empty or dismissive \
positivity ("just think positive!").
- Keep responses conversational and not overly long unless the user asks for depth.
- Never diagnose medical or mental health conditions, and never recommend specific medications or dosages.
- If the user expresses thoughts of self-harm, suicide, or being in crisis, respond with care, \
gently encourage them to reach out to a trusted person and to a crisis line or emergency services in \
their area right away, and do not attempt to handle the crisis yourself as if you were a therapist.
- If asked, clearly state that you are an AI wellness companion, not a licensed professional, and that \
for medical, psychiatric, or emergency needs they should consult a qualified professional or local \
emergency services."""


def build_system_prompt(user: models.User, memory_summary: str) -> str:
    profile = user.profile
    profile_lines = []
    if profile:
        if profile.name:
            profile_lines.append(f"Name: {profile.name}")
        if profile.occupation:
            profile_lines.append(f"Occupation: {profile.occupation}")
        if profile.sleep_goal_hours:
            profile_lines.append(f"Sleep goal: {profile.sleep_goal_hours} hours/night")
        if profile.water_goal_ml:
            profile_lines.append(f"Water goal: {profile.water_goal_ml} ml/day")
        if profile.fitness_goal:
            profile_lines.append(f"Fitness goal: {profile.fitness_goal}")
        if profile.stress_level:
            profile_lines.append(f"Self-reported baseline stress level: {profile.stress_level}/10")
        if profile.communication_style:
            profile_lines.append(f"Preferred communication style: {profile.communication_style}")

    profile_block = "\n".join(profile_lines) if profile_lines else "No profile details provided yet."
    memory_block = memory_summary.strip() if memory_summary and memory_summary.strip() else (
        "No prior memory yet — this may be an early conversation with this user."
    )

    return f"""{BASE_PERSONALITY}

--- User profile ---
{profile_block}

--- What you remember about this user (from past conversations) ---
{memory_block}
"""


def _build_contents(history: List[dict], new_message: str) -> List[types.Content]:
    """Converts plain {role, content} dicts plus the new message into the
    google-genai SDK's Content/Part structure. Gemini uses 'model' instead of
    'assistant' for the AI's role."""
    contents = []
    for m in history:
        role = "model" if m["role"] == "assistant" else "user"
        contents.append(types.Content(role=role, parts=[types.Part(text=m["content"])]))
    contents.append(types.Content(role="user", parts=[types.Part(text=new_message)]))
    return contents


def stream_chat_response(
    system_prompt: str,
    history: List[dict],
    new_message: str,
) -> Generator[str, None, None]:
    """Yields text chunks from Gemini as they arrive.

    IMPORTANT: this takes plain data only (a pre-built system prompt string and
    history as plain dicts) rather than ORM objects. It runs in a background
    thread *after* the request's database session has already been closed
    (that's how FastAPI StreamingResponse + Depends(get_db) interact), so any
    lazy-loaded SQLAlchemy attribute access in here would raise
    DetachedInstanceError. Build everything from the DB before this is called.

    Never lets an exception kill the HTTP stream silently - instead it yields
    a readable error message and logs the full details server-side.
    """
    try:
        contents = _build_contents(history, new_message)
        response_stream = _client.models.generate_content_stream(
            model=settings.GEMINI_MODEL,
            contents=contents,
            config=types.GenerateContentConfig(system_instruction=system_prompt),
        )

        for chunk in response_stream:
            if chunk.text:
                yield chunk.text
    except Exception as e:  # noqa: BLE001
        import traceback

        print("=== Gemini API error ===")
        traceback.print_exc()
        print("========================")

        if not settings.GEMINI_API_KEY:
            yield (
                "⚠️ I can't reach the AI provider because no `GEMINI_API_KEY` is set in your "
                "`.env` file. Add your free key from https://aistudio.google.com and restart "
                "the backend."
            )
        else:
            yield (
                f"⚠️ I hit an error talking to the AI provider ({type(e).__name__}). "
                "Check the backend terminal logs for the full details - it's usually an invalid "
                "API key, an unsupported model name, or a free-tier rate limit."
            )


def generate_chat_title(first_message: str) -> str:
    """Generates a short (3-6 word) title for a new chat based on the first message."""
    try:
        prompt = (
            "Generate a short 3-6 word title (no quotes, no punctuation at the end) "
            f"summarizing what this message is about:\n\n{first_message}"
        )
        result = _client.models.generate_content(model=settings.GEMINI_MODEL, contents=prompt)
        title = (result.text or "").strip().strip('"').strip()
        return title[:80] if title else first_message[:40]
    except Exception:
        return first_message[:40]


def generate_mood_insight(mood_summary_text: str) -> str:
    """Generates a short, supportive, non-diagnostic insight from a summary of
    recent mood/stress/energy/sleep check-ins."""
    try:
        prompt = f"""You are a wellness companion analyzing a user's recent daily mood check-ins.
Here is the raw data (date, mood 1-10, stress 1-10, energy 1-10, sleep quality 1-10, optional note):

{mood_summary_text}

Write a short (3-5 sentence), warm, non-clinical insight about patterns you notice (e.g. trends, \
correlations between sleep and mood, stress patterns). Do NOT diagnose any condition. Do NOT give \
medical advice. End with one small, actionable, encouraging suggestion. Output plain text only, no \
headers or bullet points."""

        result = _client.models.generate_content(model=settings.GEMINI_MODEL, contents=prompt)
        return (result.text or "").strip() or "Not enough data yet to generate an insight."
    except Exception:
        return "I couldn't generate an insight right now - please try again in a moment."


def generate_wellness_report(range_label: str, summary_text: str) -> str:
    """Generates a short narrative wellness report (3-6 sentences) from a
    structured plain-text summary of the user's mood, habits, journal, and
    planner activity over the given range ("week" or "month")."""
    try:
        prompt = f"""You are a wellness companion writing a {range_label}ly wellness report for a user, \
based on their tracked activity below (mood check-ins, habit completions, journal entries, and \
planner/focus activity):

{summary_text}

Write a warm, encouraging {range_label}ly report of 4-7 sentences. Call out one or two genuine \
patterns or connections you notice (e.g. between sleep and mood, or habit consistency and stress), \
celebrate concrete progress, and end with one small, specific, actionable suggestion for the coming \
{range_label}. Do NOT diagnose any condition, do NOT give medical advice, and do NOT use empty \
generic positivity - ground everything in the actual numbers given. Output plain text only, no \
headers or bullet points."""

        result = _client.models.generate_content(model=settings.GEMINI_MODEL, contents=prompt)
        return (result.text or "").strip() or "Not enough data yet to generate a report."
    except Exception:
        return "I couldn't generate your report right now - please try again in a moment."


def generate_journal_summary(entry_text: str) -> str:
    """Generates a short, warm, non-clinical AI summary/reflection of a single
    day's journal entry (plain text, HTML tags already stripped by the caller)."""
    try:
        prompt = f"""You are a wellness companion summarizing a user's private daily journal entry.
Here is the entry (plain text):

{entry_text}

Write a short (2-4 sentence), warm, non-judgmental summary that reflects back the key events, \
feelings, and themes in the entry. Do NOT diagnose any condition or give medical advice. Do NOT \
moralize or tell the user what they should do unless they explicitly asked for advice in the entry. \
Output plain text only, no headers or bullet points."""

        result = _client.models.generate_content(model=settings.GEMINI_MODEL, contents=prompt)
        return (result.text or "").strip() or "Not enough content yet to summarize."
    except Exception:
        return "I couldn't generate a summary right now - please try again in a moment."


def update_memory_summary(previous_summary: str, user_message: str, assistant_message: str) -> str:
    """Asks Gemini to fold the latest exchange into a concise running memory summary
    (goals, preferences, routines, stress triggers, important events, future plans)."""
    try:
        prompt = f"""You maintain a concise running memory profile of a user for a wellness companion AI.

Existing memory summary:
{previous_summary or "(empty - no memory yet)"}

Latest conversation exchange:
User: {user_message}
Assistant: {assistant_message}

Update the memory summary to incorporate any new durable facts from this exchange: goals, \
preferences, favorite activities, daily routines, stress triggers, habits, workout routine, food \
preferences, important life events, and future plans. Do NOT include transient small talk. Keep it \
under 250 words, written as concise bullet points. Output ONLY the updated summary, nothing else."""

        result = _client.models.generate_content(model=settings.GEMINI_MODEL, contents=prompt)
        updated = (result.text or "").strip()
        return updated if updated else previous_summary
    except Exception:
        # Memory update is best-effort; never break the chat flow if it fails.
        return previous_summary
