from datetime import datetime, date
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, ConfigDict


# ---------- Auth ----------

class SignupRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    name: Optional[str] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
    remember_me: bool = False


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(min_length=8, max_length=128)


# ---------- User / Profile ----------

class ProfileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    name: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    occupation: Optional[str] = None
    timezone: Optional[str] = None
    sleep_goal_hours: Optional[int] = None
    water_goal_ml: Optional[int] = None
    fitness_goal: Optional[str] = None
    weight_goal: Optional[str] = None
    study_goal_hours: Optional[int] = None
    stress_level: Optional[int] = None
    communication_style: Optional[str] = None
    emergency_contact: Optional[str] = None


class ProfileUpdate(BaseModel):
    name: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    occupation: Optional[str] = None
    timezone: Optional[str] = None
    sleep_goal_hours: Optional[int] = None
    water_goal_ml: Optional[int] = None
    fitness_goal: Optional[str] = None
    weight_goal: Optional[str] = None
    study_goal_hours: Optional[int] = None
    stress_level: Optional[int] = None
    communication_style: Optional[str] = None
    emergency_contact: Optional[str] = None


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    is_active: bool
    created_at: datetime
    profile: Optional[ProfileOut] = None


# ---------- Chat ----------

class ChatCreate(BaseModel):
    title: Optional[str] = None


class ChatUpdate(BaseModel):
    title: Optional[str] = None
    pinned: Optional[bool] = None


class ChatOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    pinned: bool
    created_at: datetime
    updated_at: datetime


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    role: str
    content: str
    created_at: datetime


class MessageCreate(BaseModel):
    content: str = Field(min_length=1, max_length=8000)


# ---------- Mood ----------

class MoodCheckIn(BaseModel):
    log_date: Optional[date] = None  # defaults to today server-side if omitted
    mood_score: int = Field(ge=1, le=10)
    stress_score: Optional[int] = Field(default=None, ge=1, le=10)
    energy_score: Optional[int] = Field(default=None, ge=1, le=10)
    sleep_quality: Optional[int] = Field(default=None, ge=1, le=10)
    note: Optional[str] = Field(default=None, max_length=2000)


class MoodLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    log_date: date
    mood_score: int
    stress_score: Optional[int] = None
    energy_score: Optional[int] = None
    sleep_quality: Optional[int] = None
    note: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class MoodInsight(BaseModel):
    insight: str
    entry_count: int


# ---------- Habits ----------

class HabitCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    category: str = Field(default="custom", pattern="^(water|sleep|exercise|custom)$")
    emoji: str = Field(default="✅", max_length=8)
    target_value: Optional[int] = Field(default=None, ge=1)
    unit: Optional[str] = Field(default=None, max_length=40)


class HabitUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    category: Optional[str] = Field(default=None, pattern="^(water|sleep|exercise|custom)$")
    emoji: Optional[str] = Field(default=None, max_length=8)
    target_value: Optional[int] = Field(default=None, ge=1)
    unit: Optional[str] = Field(default=None, max_length=40)
    is_archived: Optional[bool] = None


class HabitCheckIn(BaseModel):
    log_date: Optional[date] = None  # defaults to today server-side if omitted
    completed: bool = True
    value: Optional[int] = Field(default=None, ge=0)


class HabitLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    log_date: date
    completed: bool
    value: Optional[int] = None
    created_at: datetime


class HabitOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    category: str
    emoji: str
    target_value: Optional[int] = None
    unit: Optional[str] = None
    is_archived: bool
    created_at: datetime
    updated_at: datetime

    current_streak: int = 0
    longest_streak: int = 0
    completed_today: bool = False
    today_value: Optional[int] = None


# ---------- Journal ----------

class JournalEntryCreate(BaseModel):
    entry_date: Optional[date] = None  # defaults to today server-side if omitted
    title: Optional[str] = Field(default=None, max_length=200)
    content: str = Field(min_length=1, max_length=50000)
    mood_tag: Optional[str] = Field(default=None, max_length=8)


class JournalEntryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    entry_date: date
    title: Optional[str] = None
    content: str
    mood_tag: Optional[str] = None
    ai_summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class JournalSummaryOut(BaseModel):
    summary: str


# ---------- Planner: To-dos ----------

class TodoCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    description: Optional[str] = Field(default=None, max_length=2000)
    due_date: Optional[date] = None
    due_time: Optional[str] = Field(default=None, pattern="^([01]\\d|2[0-3]):[0-5]\\d$")
    priority: str = Field(default="medium", pattern="^(low|medium|high)$")


class TodoUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = Field(default=None, max_length=2000)
    due_date: Optional[date] = None
    due_time: Optional[str] = Field(default=None, pattern="^([01]\\d|2[0-3]):[0-5]\\d$")
    priority: Optional[str] = Field(default=None, pattern="^(low|medium|high)$")
    is_completed: Optional[bool] = None


class TodoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    description: Optional[str] = None
    due_date: Optional[date] = None
    due_time: Optional[str] = None
    priority: str
    is_completed: bool
    completed_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime


# ---------- Planner: Pomodoro ----------

class PomodoroCreate(BaseModel):
    task_label: Optional[str] = Field(default=None, max_length=200)
    duration_minutes: int = Field(default=25, ge=1, le=180)


class PomodoroOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    task_label: Optional[str] = None
    duration_minutes: int
    completed_at: datetime


class PomodoroStats(BaseModel):
    sessions_today: int
    focus_minutes_today: int


# ---------- Insights ----------

class MoodInsightsSummary(BaseModel):
    entry_count: int
    avg_mood: Optional[float] = None
    avg_stress: Optional[float] = None
    avg_energy: Optional[float] = None
    avg_sleep_quality: Optional[float] = None


class HabitInsightsSummary(BaseModel):
    name: str
    emoji: str
    completions: int
    days_in_range: int
    completion_rate: float  # 0-1
    current_streak: int
    longest_streak: int


class JournalInsightsSummary(BaseModel):
    entry_count: int
    top_mood_tags: list[str] = []


class PlannerInsightsSummary(BaseModel):
    todos_completed: int
    todos_total: int
    pomodoro_sessions: int
    pomodoro_minutes: int


class WellnessReport(BaseModel):
    range: str  # "week" | "month"
    generated_at: datetime
    mood: MoodInsightsSummary
    habits: list[HabitInsightsSummary]
    journal: JournalInsightsSummary
    planner: PlannerInsightsSummary
    ai_report: str
