from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import auth, users, chat, mood, habits, journal, planner, insights

app = FastAPI(
    title="MindMate AI API",
    description="Backend API for MindMate AI - Your Personal AI Wellness Companion",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(chat.router)
app.include_router(mood.router)
app.include_router(habits.router)
app.include_router(journal.router)
app.include_router(planner.router)
app.include_router(insights.router)


@app.get("/api/health", tags=["health"])
def health_check():
    return {"status": "ok", "environment": settings.ENVIRONMENT}


@app.get("/", tags=["health"])
def root():
    return {"message": "MindMate AI API is running. See /docs for API documentation."}
