import uuid
from datetime import datetime, date

from sqlalchemy import (
    Column,
    String,
    Integer,
    Boolean,
    DateTime,
    Date,
    ForeignKey,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.database import Base


def gen_uuid():
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    email = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    profile = relationship("Profile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    refresh_tokens = relationship("RefreshToken", back_populates="user", cascade="all, delete-orphan")
    chats = relationship("Chat", back_populates="user", cascade="all, delete-orphan")
    ai_memory = relationship("AIMemory", back_populates="user", uselist=False, cascade="all, delete-orphan")
    mood_logs = relationship("MoodLog", back_populates="user", cascade="all, delete-orphan")
    habits = relationship("Habit", back_populates="user", cascade="all, delete-orphan")
    journal_entries = relationship("JournalEntry", back_populates="user", cascade="all, delete-orphan")
    todos = relationship("Todo", back_populates="user", cascade="all, delete-orphan")
    pomodoro_sessions = relationship("PomodoroSession", back_populates="user", cascade="all, delete-orphan")


class Profile(Base):
    __tablename__ = "profiles"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), unique=True, nullable=False)

    name = Column(String, nullable=True)
    age = Column(Integer, nullable=True)
    gender = Column(String, nullable=True)
    occupation = Column(String, nullable=True)
    timezone = Column(String, default="UTC")

    sleep_goal_hours = Column(Integer, nullable=True)
    water_goal_ml = Column(Integer, nullable=True)
    fitness_goal = Column(String, nullable=True)
    weight_goal = Column(String, nullable=True)
    study_goal_hours = Column(Integer, nullable=True)

    stress_level = Column(Integer, nullable=True)  # 1-10 self-reported baseline
    communication_style = Column(String, default="balanced")  # e.g. direct, gentle, balanced
    emergency_contact = Column(String, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="profile")


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    token = Column(Text, unique=True, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    revoked = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="refresh_tokens")


class Chat(Base):
    __tablename__ = "chats"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    title = Column(String, default="New chat")
    pinned = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="chats")
    messages = relationship(
        "Message",
        back_populates="chat",
        cascade="all, delete-orphan",
        order_by="Message.created_at",
    )


class Message(Base):
    __tablename__ = "messages"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    chat_id = Column(UUID(as_uuid=False), ForeignKey("chats.id"), nullable=False, index=True)
    role = Column(String, nullable=False)  # "user" | "assistant"
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    chat = relationship("Chat", back_populates="messages")


class AIMemory(Base):
    """A single running summary of what the AI has learned about the user
    (goals, preferences, routines, important events). Updated after each
    conversation turn and injected into future system prompts."""

    __tablename__ = "ai_memory"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), unique=True, nullable=False)
    summary = Column(Text, default="")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="ai_memory")


class MoodLog(Base):
    """A single daily mood check-in. One row per user per calendar day
    (enforced by a unique constraint), so re-submitting the same day updates
    the existing entry instead of creating a duplicate."""

    __tablename__ = "mood_logs"
    __table_args__ = (UniqueConstraint("user_id", "log_date", name="uq_mood_logs_user_date"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    log_date = Column(Date, nullable=False, default=date.today)

    mood_score = Column(Integer, nullable=False)  # 1-10
    stress_score = Column(Integer, nullable=True)  # 1-10
    energy_score = Column(Integer, nullable=True)  # 1-10
    sleep_quality = Column(Integer, nullable=True)  # 1-10
    note = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="mood_logs")


class Habit(Base):
    """A habit the user wants to track daily (water, sleep, exercise, or a
    custom habit). Actual completions are stored per-day in HabitLog."""

    __tablename__ = "habits"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)

    name = Column(String, nullable=False)
    category = Column(String, default="custom")  # water | sleep | exercise | custom
    emoji = Column(String, default="✅")
    target_value = Column(Integer, nullable=True)  # e.g. 8 (glasses), 8 (hours), 30 (minutes)
    unit = Column(String, nullable=True)  # e.g. "glasses", "hours", "minutes", "times"
    is_archived = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="habits")
    logs = relationship(
        "HabitLog",
        back_populates="habit",
        cascade="all, delete-orphan",
        order_by="HabitLog.log_date",
    )


class HabitLog(Base):
    """A single day's completion record for a habit. One row per habit per
    calendar day (enforced by a unique constraint), so re-submitting the same
    day updates the existing entry instead of creating a duplicate."""

    __tablename__ = "habit_logs"
    __table_args__ = (UniqueConstraint("habit_id", "log_date", name="uq_habit_logs_habit_date"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    habit_id = Column(UUID(as_uuid=False), ForeignKey("habits.id"), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    log_date = Column(Date, nullable=False, default=date.today)

    completed = Column(Boolean, default=True)
    value = Column(Integer, nullable=True)  # optional actual amount logged (e.g. 6 glasses)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    habit = relationship("Habit", back_populates="logs")


class JournalEntry(Base):
    """A rich-text daily journal entry. One row per user per calendar day
    (enforced by a unique constraint), so re-saving the same day updates the
    existing entry instead of creating a duplicate. `ai_summary` caches the
    last AI-generated summary so it doesn't need to be regenerated every time
    the entry is viewed."""

    __tablename__ = "journal_entries"
    __table_args__ = (UniqueConstraint("user_id", "entry_date", name="uq_journal_entries_user_date"),)

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)
    entry_date = Column(Date, nullable=False, default=date.today)

    title = Column(String, nullable=True)
    content = Column(Text, nullable=False, default="")  # sanitized rich-text HTML
    mood_tag = Column(String, nullable=True)  # optional quick emoji tag, e.g. "😊"
    ai_summary = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="journal_entries")


class Todo(Base):
    """A daily-planner to-do item. Doubles as the calendar item (grouped by
    `due_date` client-side) so there's a single source of truth for
    scheduled tasks."""

    __tablename__ = "todos"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)

    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    due_date = Column(Date, nullable=True, index=True)  # null = unscheduled / "someday"
    due_time = Column(String, nullable=True)  # "HH:MM", optional
    priority = Column(String, default="medium")  # low | medium | high
    is_completed = Column(Boolean, default=False)
    completed_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="todos")


class PomodoroSession(Base):
    """A single completed Pomodoro focus session, logged for lightweight
    daily/streak stats on the planner page."""

    __tablename__ = "pomodoro_sessions"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False, index=True)

    task_label = Column(String, nullable=True)
    duration_minutes = Column(Integer, default=25)
    completed_at = Column(DateTime, default=datetime.utcnow)

    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="pomodoro_sessions")
